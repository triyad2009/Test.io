import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';

import { Palette } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';

interface Props {
  size?: number;
  strokeWidth?: number;
  progress: number; // 0..1
  color?: string;
  centerLabel?: string;
  centerSub?: string;
}

/** Circular progress ring. Uses SVG so it stays crisp on every density. */
export function ProgressRing({
  size = 148,
  strokeWidth = 14,
  progress,
  color,
  centerLabel,
  centerSub,
}: Props) {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);
  const clamped = Math.min(1, Math.max(0, Number.isFinite(progress) ? progress : 0));
  const radiusValue = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radiusValue;
  const dashOffset = circumference * (1 - clamped);

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size}>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radiusValue}
          stroke={palette.track}
          strokeWidth={strokeWidth}
          fill="none"
        />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radiusValue}
          stroke={color || palette.primary}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={`${circumference} ${circumference}`}
          strokeDashoffset={dashOffset}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </Svg>
      <View style={StyleSheet.absoluteFillObject as never} pointerEvents="none">
        <View style={styles.center}>
          {centerLabel ? <Text style={styles.label}>{centerLabel}</Text> : null}
          {centerSub ? <Text style={styles.sub}>{centerSub}</Text> : null}
        </View>
      </View>
    </View>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
    label: { color: palette.text, fontSize: 30, fontWeight: '800' },
    sub: { color: palette.textMuted, fontSize: 12, fontWeight: '600', marginTop: 2 },
  });
}

/** Horizontal progress bar used inside habit rows. */
export function ProgressBar({ progress, color }: { progress: number; color: string }) {
  const { palette } = useAppTheme();
  const clamped = Math.min(1, Math.max(0, Number.isFinite(progress) ? progress : 0));
  return (
    <View style={{ height: 6, borderRadius: 3, backgroundColor: palette.track, overflow: 'hidden' }}>
      <View
        style={{
          width: `${clamped * 100}%`,
          height: '100%',
          borderRadius: 3,
          backgroundColor: color,
        }}
      />
    </View>
  );
}
