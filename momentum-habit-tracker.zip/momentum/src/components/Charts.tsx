import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { Habit, Logs } from '../types';
import { Palette, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';
import { lastNDays, weekdayIndex } from '../utils/date';
import { dayProgress, isDoneOn } from '../utils/streaks';

interface HeatmapProps {
  habit: Habit;
  logs: Logs;
  weeks?: number;
}

/** GitHub-style contribution grid: columns = weeks, rows = weekday. */
export function Heatmap({ habit, logs, weeks = 14 }: HeatmapProps) {
  const { palette } = useAppTheme();
  const styles = makeHeatmapStyles(palette);

  const total = weeks * 7;
  const keys = lastNDays(total);
  // Pad the first column so weekday rows line up with real weekdays.
  const leading = weekdayIndex(keys[0]);

  const cells: (string | null)[] = [...Array(leading).fill(null), ...keys];
  const columns: (string | null)[][] = [];
  for (let i = 0; i < cells.length; i += 7) {
    columns.push(cells.slice(i, i + 7));
  }

  const labelFor = (index: number) => (index % 2 === 0 ? ['S', 'M', 'T', 'W', 'T', 'F', 'S'][index] : '');

  return (
    <View>
      <View style={styles.gridRow}>
        <View style={styles.weekdayCol}>
          {[0, 1, 2, 3, 4, 5, 6].map((i) => (
            <Text key={i} style={styles.weekdayLabel}>
              {labelFor(i)}
            </Text>
          ))}
        </View>
        <View style={styles.grid}>
          {columns.map((column, ci) => (
            <View key={ci} style={styles.column}>
              {Array.from({ length: 7 }).map((_, ri) => {
                const key = column[ri] ?? null;
                if (!key) {
                  return <View key={ri} style={[styles.cell, styles.cellEmpty]} />;
                }
                const progress = dayProgress(habit, logs, key);
                const done = isDoneOn(habit, logs, key);
                const bg = done
                  ? habit.color
                  : progress > 0
                    ? `${habit.color}66`
                    : palette.track;
                return <View key={ri} style={[styles.cell, { backgroundColor: bg }]} />;
              })}
            </View>
          ))}
        </View>
      </View>

      <View style={styles.legend}>
        <Text style={styles.legendText}>Less</Text>
        <View style={[styles.legendCell, { backgroundColor: palette.track }]} />
        <View style={[styles.legendCell, { backgroundColor: `${habit.color}66` }]} />
        <View style={[styles.legendCell, { backgroundColor: habit.color }]} />
        <Text style={styles.legendText}>More</Text>
      </View>
    </View>
  );
}

function makeHeatmapStyles(palette: Palette) {
  return StyleSheet.create({
    gridRow: { flexDirection: 'row', gap: spacing.sm },
    weekdayCol: { justifyContent: 'space-between', paddingVertical: 1 },
    weekdayLabel: { color: palette.textFaint, fontSize: 9, height: 15, lineHeight: 15 },
    grid: { flexDirection: 'row', gap: 3 },
    column: { gap: 3 },
    cell: { width: 15, height: 15, borderRadius: 4 },
    cellEmpty: { backgroundColor: 'transparent' },
    legend: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: spacing.sm,
      marginTop: spacing.md,
      justifyContent: 'flex-end',
    },
    legendText: { color: palette.textFaint, fontSize: 11 },
    legendCell: { width: 12, height: 12, borderRadius: 3 },
  });
}

interface BarsProps {
  values: number[]; // 0..1
  labels: string[];
  color: string;
  height?: number;
}

/** Simple dependency-free column chart. */
export function BarChart({ values, labels, color, height = 110 }: BarsProps) {
  const { palette } = useAppTheme();
  const styles = makeBarStyles(palette);
  return (
    <View>
      <View style={[styles.chartRow, { height }]}>
        {values.map((value, index) => {
          const clamped = Math.min(1, Math.max(0, value));
          const barHeight = Math.max(4, Math.round(clamped * (height - 18)));
          return (
            <View key={index} style={styles.barColumn}>
              <Text style={styles.barValue}>{Math.round(clamped * 100)}</Text>
              <View
                style={{
                  width: '62%',
                  height: barHeight,
                  borderRadius: 6,
                  backgroundColor: clamped >= 0.999 ? color : `${color}99`,
                }}
              />
            </View>
          );
        })}
      </View>
      <View style={styles.chartLabels}>
        {labels.map((label, index) => (
          <Text key={index} style={styles.chartLabel}>
            {label}
          </Text>
        ))}
      </View>
    </View>
  );
}

function makeBarStyles(palette: Palette) {
  return StyleSheet.create({
    chartRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 2 },
    barColumn: { flex: 1, alignItems: 'center', justifyContent: 'flex-end', height: '100%' },
    barValue: { color: palette.textFaint, fontSize: 9, marginBottom: 2 },
    chartLabels: { flexDirection: 'row', marginTop: spacing.sm },
    chartLabel: { flex: 1, textAlign: 'center', color: palette.textMuted, fontSize: 11, fontWeight: '600' },
  });
}
