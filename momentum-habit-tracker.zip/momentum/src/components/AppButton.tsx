import React from 'react';
import { Pressable, StyleSheet, Text, View, ViewStyle } from 'react-native';

import { Palette, radius, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';

interface Props {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  disabled?: boolean;
  icon?: string;
  fullWidth?: boolean;
  style?: ViewStyle;
}

export function AppButton({
  label,
  onPress,
  variant = 'primary',
  disabled = false,
  icon,
  fullWidth = true,
  style,
}: Props) {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);

  const bg =
    variant === 'primary'
      ? palette.primary
      : variant === 'secondary'
        ? palette.surfaceAlt
        : variant === 'danger'
          ? palette.danger
          : 'transparent';

  const fg =
    variant === 'primary' || variant === 'danger'
      ? palette.onPrimary
      : variant === 'ghost'
        ? palette.primary
        : palette.text;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled }}
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.base,
        { backgroundColor: bg, opacity: disabled ? 0.45 : pressed ? 0.85 : 1 },
        fullWidth && styles.fullWidth,
        variant === 'ghost' && styles.ghost,
        style,
      ]}
    >
      {icon ? <Text style={[styles.icon, { color: fg }]}>{icon}</Text> : null}
      <Text style={[styles.label, { color: fg }]}>{label}</Text>
    </Pressable>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    base: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 14,
      paddingHorizontal: spacing.xl,
      borderRadius: radius.pill,
      gap: spacing.sm,
    },
    fullWidth: { alignSelf: 'stretch' },
    ghost: { borderWidth: 1, borderColor: palette.border },
    icon: { fontSize: 16 },
    label: { fontSize: 15, fontWeight: '700', letterSpacing: 0.2 },
  });
}

/** Small inline pill used for filters and quick stats. */
export function Pill({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  const { palette } = useAppTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: active }}
      onPress={onPress}
      style={{
        paddingHorizontal: spacing.lg,
        paddingVertical: spacing.sm,
        borderRadius: radius.pill,
        backgroundColor: active ? palette.primary : palette.surfaceAlt,
      }}
    >
      <Text
        style={{
          color: active ? palette.onPrimary : palette.textMuted,
          fontWeight: '600',
          fontSize: 13,
        }}
      >
        {label}
      </Text>
    </Pressable>
  );
}

export function SectionTitle({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  const { palette } = useAppTheme();
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: spacing.md,
        marginTop: spacing.xl,
      }}
    >
      <Text style={{ color: palette.text, fontSize: 18, fontWeight: '700' }}>{children}</Text>
      {right}
    </View>
  );
}
