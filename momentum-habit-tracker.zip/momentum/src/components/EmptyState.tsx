import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { Palette, radius, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';

export function EmptyState({
  emoji,
  title,
  body,
  children,
}: {
  emoji: string;
  title: string;
  body: string;
  children?: React.ReactNode;
}) {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);
  return (
    <View style={styles.wrap}>
      <View style={styles.badge}>
        <Text style={styles.emoji}>{emoji}</Text>
      </View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.body}>{body}</Text>
      {children ? <View style={styles.actions}>{children}</View> : null}
    </View>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    wrap: { alignItems: 'center', paddingVertical: spacing.xxl, paddingHorizontal: spacing.xl },
    badge: {
      width: 74,
      height: 74,
      borderRadius: 37,
      backgroundColor: palette.primarySoft,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: spacing.lg,
    },
    emoji: { fontSize: 32 },
    title: { color: palette.text, fontSize: 19, fontWeight: '800', textAlign: 'center' },
    body: {
      color: palette.textMuted,
      fontSize: 14,
      textAlign: 'center',
      marginTop: spacing.sm,
      lineHeight: 20,
    },
    actions: { marginTop: spacing.xl, width: '100%', alignItems: 'center' },
  });
}

export function Card({
  children,
  style,
}: {
  children: React.ReactNode;
  style?: object;
}) {
  const { palette } = useAppTheme();
  return (
    <View
      style={[
        {
          backgroundColor: palette.surface,
          borderRadius: radius.lg,
          borderWidth: 1,
          borderColor: palette.border,
          padding: spacing.lg,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function Divider() {
  const { palette } = useAppTheme();
  return <View style={{ height: 1, backgroundColor: palette.border, marginVertical: spacing.md }} />;
}
