import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { Habit, Logs } from '../types';
import { Palette, radius, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';
import { dayProgress, isDoneOn, valueFor } from '../utils/streaks';
import { ProgressBar } from './ProgressRing';

interface Props {
  habit: Habit;
  logs: Logs;
  dateKey: string;
  streak: number;
  onPress: () => void;
  onCheck: () => void;
  onStep: (delta: number) => void;
}

export function HabitCard({
  habit,
  logs,
  dateKey,
  streak,
  onPress,
  onCheck,
  onStep,
}: Props) {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);
  const done = isDoneOn(habit, logs, dateKey);
  const value = valueFor(habit, logs, dateKey);
  const progress = dayProgress(habit, logs, dateKey);
  const goal = Math.max(1, habit.goal);

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${habit.name}, ${value} of ${goal}, ${done ? 'complete' : 'not complete'}`}
      onPress={onPress}
      style={({ pressed }) => [styles.card, pressed && { opacity: 0.92 }]}
    >
      <View style={[styles.emojiWrap, { backgroundColor: `${habit.color}22` }]}>
        <Text style={styles.emoji}>{habit.emoji}</Text>
      </View>

      <View style={styles.body}>
        <View style={styles.titleRow}>
          <Text style={styles.title} numberOfLines={1}>
            {habit.name}
          </Text>
          {streak > 0 ? (
            <View style={[styles.streakChip, { backgroundColor: `${habit.color}22` }]}>
              <Text style={[styles.streakText, { color: habit.color }]}>🔥 {streak}</Text>
            </View>
          ) : null}
        </View>

        <Text style={styles.meta}>
          {habit.kind === 'count'
            ? `${value} / ${goal}${habit.unit ? ` ${habit.unit}` : ''} today`
            : done
              ? 'Done today'
              : 'Not logged yet'}
        </Text>

        <View style={styles.progressWrap}>
          <ProgressBar progress={progress} color={habit.color} />
        </View>
      </View>

      {habit.kind === 'count' ? (
        <View style={styles.stepper}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`Decrease ${habit.name}`}
            hitSlop={8}
            onPress={() => onStep(-1)}
            style={styles.stepBtn}
          >
            <Text style={styles.stepText}>−</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`Increase ${habit.name}`}
            hitSlop={8}
            onPress={() => onStep(1)}
            style={styles.stepBtn}
          >
            <Text style={styles.stepText}>+</Text>
          </Pressable>
        </View>
      ) : null}

      <Pressable
        accessibilityRole="checkbox"
        accessibilityState={{ checked: done }}
        accessibilityLabel={`Mark ${habit.name} ${done ? 'incomplete' : 'complete'}`}
        hitSlop={8}
        onPress={onCheck}
        style={[
          styles.check,
          done
            ? { backgroundColor: habit.color, borderColor: habit.color }
            : { borderColor: palette.border },
        ]}
      >
        <Text style={[styles.checkMark, { color: done ? '#FFFFFF' : 'transparent' }]}>✓</Text>
      </Pressable>
    </Pressable>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    card: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: palette.surface,
      borderRadius: radius.lg,
      borderWidth: 1,
      borderColor: palette.border,
      padding: spacing.md,
      marginBottom: spacing.md,
      gap: spacing.md,
    },
    emojiWrap: {
      width: 46,
      height: 46,
      borderRadius: radius.md,
      alignItems: 'center',
      justifyContent: 'center',
    },
    emoji: { fontSize: 22 },
    body: { flex: 1 },
    titleRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
    title: { color: palette.text, fontSize: 16, fontWeight: '700', flexShrink: 1 },
    streakChip: {
      paddingHorizontal: spacing.sm,
      paddingVertical: 2,
      borderRadius: radius.pill,
    },
    streakText: { fontSize: 11, fontWeight: '700' },
    meta: { color: palette.textMuted, fontSize: 12.5, marginTop: 3 },
    progressWrap: { marginTop: spacing.sm },
    stepper: { flexDirection: 'row', gap: spacing.xs },
    stepBtn: {
      width: 30,
      height: 30,
      borderRadius: 15,
      backgroundColor: palette.surfaceAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    stepText: { color: palette.text, fontSize: 18, fontWeight: '700', lineHeight: 20 },
    check: {
      width: 34,
      height: 34,
      borderRadius: 17,
      borderWidth: 2,
      alignItems: 'center',
      justifyContent: 'center',
    },
    checkMark: { fontSize: 17, fontWeight: '900' },
  });
}
