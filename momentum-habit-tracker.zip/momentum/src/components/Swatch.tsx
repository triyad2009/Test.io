import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { Palette, radius, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';
import { isHexDark } from '../theme/theme';

interface Props {
  name: string;
  emoji: string;
  color: string;
  selected: boolean;
  onPress: () => void;
  subtitle?: string;
}

/** Reusable picker tile used by the emoji and colour grids. */
export function Swatch({
  name,
  emoji,
  color,
  selected,
  onPress,
  subtitle,
}: Props) {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);
  const isColor = color.startsWith('#');
  const fg = isColor ? (isHexDark(color) ? '#FFFFFF' : '#111111') : palette.text;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      accessibilityLabel={`${name}${selected ? ', selected' : ''}`}
      onPress={onPress}
      style={[
        styles.swatch,
        { backgroundColor: isColor ? color : palette.surfaceAlt },
        selected && { borderColor: palette.text, borderWidth: 2.5 },
      ]}
    >
      {emoji ? <Text style={{ fontSize: 20 }}>{emoji}</Text> : null}
      {subtitle ? (
        <Text style={[styles.subtitle, { color: isColor ? fg : palette.textMuted }]}>{subtitle}</Text>
      ) : null}
    </Pressable>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    swatch: {
      width: 44,
      height: 44,
      borderRadius: radius.md,
      borderWidth: 1,
      borderColor: palette.border,
      alignItems: 'center',
      justifyContent: 'center',
    },
    subtitle: { fontSize: 10, fontWeight: '700', marginTop: 1 },
  });
}

export function ColorSwatch({
  color,
  selected,
  onPress,
}: {
  color: string;
  selected: boolean;
  onPress: () => void;
}) {
  const { palette } = useAppTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      accessibilityLabel={`Colour ${color}${selected ? ', selected' : ''}`}
      onPress={onPress}
      style={{
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: color,
        borderWidth: selected ? 3 : 1,
        borderColor: selected ? palette.text : palette.border,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {selected ? <Text style={{ color: isHexDark(color) ? '#fff' : '#111', fontWeight: '900' }}>✓</Text> : null}
    </Pressable>
  );
}

export function Stepper({
  value,
  onChange,
  min,
  max,
  suffix,
}: {
  value: number;
  onChange: (next: number) => void;
  min: number;
  max: number;
  suffix?: string;
}) {
  const { palette } = useAppTheme();
  const styles = StyleSheet.create({
    row: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg },
    btn: {
      width: 40,
      height: 40,
      borderRadius: 20,
      backgroundColor: palette.surfaceAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    btnText: { color: palette.text, fontSize: 20, fontWeight: '700', lineHeight: 22 },
    value: { color: palette.text, fontSize: 18, fontWeight: '800', minWidth: 84, textAlign: 'center' },
  });

  return (
    <View style={styles.row}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Decrease goal"
        onPress={() => onChange(Math.max(min, value - 1))}
        style={styles.btn}
      >
        <Text style={styles.btnText}>−</Text>
      </Pressable>
      <Text style={styles.value}>
        {value}
        {suffix ? <Text style={{ color: palette.textMuted, fontSize: 13 }}> {suffix}</Text> : null}
      </Text>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Increase goal"
        onPress={() => onChange(Math.min(max, value + 1))}
        style={styles.btn}
      >
        <Text style={styles.btnText}>+</Text>
      </Pressable>
    </View>
  );
}
