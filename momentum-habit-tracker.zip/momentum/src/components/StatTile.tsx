import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { Palette, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';

interface Props {
  label: string;
  value: string;
  hint?: string;
  accent?: string;
}

export function StatTile({ label, value, hint, accent }: Props) {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);
  return (
    <View style={styles.tile}>
      <Text style={[styles.value, accent ? { color: accent } : null]}>{value}</Text>
      <Text style={styles.label}>{label}</Text>
      {hint ? <Text style={styles.hint}>{hint}</Text> : null}
    </View>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    tile: {
      flex: 1,
      minWidth: 104,
      backgroundColor: palette.surface,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: palette.border,
      paddingVertical: spacing.lg,
      paddingHorizontal: spacing.md,
      alignItems: 'center',
      justifyContent: 'center',
    },
    value: { color: palette.text, fontSize: 22, fontWeight: '800' },
    label: { color: palette.textMuted, fontSize: 12, marginTop: spacing.xs, fontWeight: '600' },
    hint: { color: palette.textFaint, fontSize: 11, marginTop: 2 },
  });
}
