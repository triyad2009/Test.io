import { useContext } from 'react';

import { HabitContext } from '../store/HabitContext';
import type { HabitContextValue } from '../store/HabitContext';

export function useHabits(): HabitContextValue {
  const ctx = useContext(HabitContext);
  if (!ctx) {
    throw new Error('useHabits must be used inside <HabitProvider>');
  }
  return ctx;
}
