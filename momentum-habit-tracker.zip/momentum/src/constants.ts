export const habitEmojis = [
  '💧', '📖', '🏃', '🧘', '💪', '🥗', '😴', '🧠',
  '✍️', '🎸', '🌱', '☀️', '🚭', '💊', '🦷', '🧹',
  '📵', '🎯', '🚴', '🏊', '🧑‍💻', '☕', '🙏', '🐶',
];

export const habitColors = [
  '#4F46E5', // indigo
  '#0EA5E9', // sky
  '#10B981', // emerald
  '#F59E0B', // amber
  '#EF4444', // red
  '#EC4899', // pink
  '#8B5CF6', // violet
  '#14B8A6', // teal
  '#F97316', // orange
  '#6366F1', // periwinkle
];

export const reminderPresets: { label: string; value: string | null }[] = [
  { label: 'None', value: null },
  { label: '7:00 AM', value: '07:00' },
  { label: '8:30 AM', value: '08:30' },
  { label: '12:00 PM', value: '12:00' },
  { label: '6:00 PM', value: '18:00' },
  { label: '9:30 PM', value: '21:30' },
];

export const filterOptions = ['All', 'Active', 'Archived'] as const;
export type FilterOption = (typeof filterOptions)[number];
