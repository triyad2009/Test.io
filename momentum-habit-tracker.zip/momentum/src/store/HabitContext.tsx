import React, {
  createContext,
  useCallback,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  useState,
} from 'react';

import { Habit, HabitKind, PersistedState, Settings } from '../types';
import {
  STATE_VERSION,
  defaultSettings,
  clearState,
  loadState,
  saveState,
} from '../storage/persistence';
import { seedState } from '../storage/seed';
import { todayKey } from '../utils/date';
import { createId } from '../utils/id';
import {
  cancelAllReminders,
  cancelReminder,
  ensurePermission,
  initNotifications,
  scheduleHabitReminder,
} from '../notifications/reminders';

export interface NewHabitInput {
  name: string;
  emoji: string;
  color: string;
  kind: HabitKind;
  goal: number;
  unit: string;
  reminder: string | null;
}

export interface HabitContextValue {
  state: PersistedState;
  ready: boolean;
  createHabit: (input: NewHabitInput) => Promise<Habit>;
  updateHabit: (id: string, patch: Partial<NewHabitInput>) => Promise<void>;
  setArchived: (id: string, archived: boolean) => void;
  deleteHabit: (id: string) => Promise<void>;
  setReminder: (id: string, time: string | null) => Promise<boolean>;
  setValue: (id: string, value: number, key?: string) => void;
  bumpValue: (id: string, delta: number) => void;
  checkIn: (id: string) => void;
  clearDay: (id: string, key?: string) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  refreshNotificationPermission: () => Promise<void>;
  loadDemoData: () => Promise<void>;
  resetEverything: () => Promise<void>;
}

type Action =
  | { type: 'hydrate'; state: PersistedState }
  | { type: 'add'; habit: Habit }
  | { type: 'update'; id: string; patch: Partial<Habit> }
  | { type: 'delete'; id: string }
  | { type: 'setValue'; id: string; key: string; value: number }
  | { type: 'clearDay'; id: string; key: string }
  | { type: 'settings'; patch: Partial<Settings> }
  | { type: 'reset' };

const initialState: PersistedState = {
  version: STATE_VERSION,
  habits: [],
  logs: {},
  settings: { ...defaultSettings },
};

function reducer(state: PersistedState, action: Action): PersistedState {
  switch (action.type) {
    case 'hydrate':
      return action.state;

    case 'add':
      return { ...state, habits: [...state.habits, action.habit] };

    case 'update':
      return {
        ...state,
        habits: state.habits.map((h) => (h.id === action.id ? { ...h, ...action.patch } : h)),
      };

    case 'delete': {
      const logs = { ...state.logs };
      delete logs[action.id];
      return { ...state, habits: state.habits.filter((h) => h.id !== action.id), logs };
    }

    case 'setValue': {
      const habit = state.habits.find((h) => h.id === action.id);
      if (!habit) return state;
      const day = { ...(state.logs[action.id] || {}) };
      const clamped = Math.max(0, Math.min(9999, Math.round(action.value)));
      if (clamped <= 0) {
        delete day[action.key];
      } else {
        day[action.key] = clamped;
      }
      const logs = { ...state.logs };
      if (Object.keys(day).length === 0) {
        delete logs[action.id];
      } else {
        logs[action.id] = day;
      }
      return { ...state, logs };
    }

    case 'clearDay': {
      const day = { ...(state.logs[action.id] || {}) };
      delete day[action.key];
      const logs = { ...state.logs };
      if (Object.keys(day).length === 0) {
        delete logs[action.id];
      } else {
        logs[action.id] = day;
      }
      return { ...state, logs };
    }

    case 'settings':
      return { ...state, settings: { ...state.settings, ...action.patch } };

    case 'reset':
      return { version: STATE_VERSION, habits: [], logs: {}, settings: { ...defaultSettings } };

    default:
      return state;
  }
}

export const HabitContext = createContext<HabitContextValue | null>(null);

export function HabitProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [ready, setReady] = useState(false);
  const hydratedRef = useRef(false);
  const stateRef = useRef(state);
  stateRef.current = state;

  // ---- Boot: load persisted state (or seed a first-run experience) ----------
  useEffect(() => {
    let cancelled = false;
    (async () => {
      await initNotifications();
      const loaded = await loadState();
      if (cancelled) return;
      if (loaded && loaded.habits.length > 0) {
        dispatch({ type: 'hydrate', state: loaded });
      } else {
        const seeded = seedState();
        dispatch({ type: 'hydrate', state: seeded });
        await saveState(seeded);
      }
      hydratedRef.current = true;
      setReady(true);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // ---- Persist on every mutation (once hydrated) ---------------------------
  useEffect(() => {
    if (!hydratedRef.current) return;
    saveState(state);
  }, [state]);

  const createHabit = useCallback(async (input: NewHabitInput): Promise<Habit> => {
    const habit: Habit = {
      id: createId('habit'),
      name: input.name.trim().slice(0, 60) || 'New habit',
      emoji: input.emoji || '🎯',
      color: input.color,
      kind: input.kind,
      goal: input.kind === 'check' ? 1 : Math.max(2, Math.round(input.goal)),
      unit: input.unit.trim().slice(0, 16),
      createdAt: todayKey(),
      reminder: input.reminder,
      reminderId: null,
      archived: false,
    };

    if (habit.reminder) {
      const id = await scheduleHabitReminder({
        habitId: habit.id,
        habitName: habit.name,
        emoji: habit.emoji,
        time: habit.reminder,
      });
      if (id) habit.reminderId = id;
    }

    dispatch({ type: 'add', habit });
    return habit;
  }, []);

  const updateHabit = useCallback(async (id: string, patch: Partial<NewHabitInput>) => {
    const current = stateRef.current.habits.find((h) => h.id === id);
    if (!current) return;

    const nextGoal = patch.kind === 'check' ? 1 : Math.max(2, Math.round(patch.goal ?? current.goal));
    const nextReminder = patch.reminder !== undefined ? patch.reminder : current.reminder;

    // Re-arm the OS reminder whenever the time changes.
    let reminderId = current.reminderId;
    if (patch.reminder !== undefined && patch.reminder !== current.reminder) {
      await cancelReminder(current.reminderId);
      reminderId = null;
      if (nextReminder) {
        reminderId = await scheduleHabitReminder({
          habitId: id,
          habitName: patch.name?.trim() || current.name,
          emoji: patch.emoji || current.emoji,
          time: nextReminder,
        });
      }
    }

    dispatch({
      type: 'update',
      id,
      patch: {
        ...(patch.name !== undefined ? { name: patch.name.trim().slice(0, 60) || current.name } : {}),
        ...(patch.emoji !== undefined ? { emoji: patch.emoji } : {}),
        ...(patch.color !== undefined ? { color: patch.color } : {}),
        ...(patch.kind !== undefined ? { kind: patch.kind } : {}),
        ...(patch.goal !== undefined || patch.kind !== undefined ? { goal: nextGoal } : {}),
        ...(patch.unit !== undefined ? { unit: patch.unit.trim().slice(0, 16) } : {}),
        reminder: nextReminder,
        reminderId,
      },
    });
  }, []);

  const setArchived = useCallback((id: string, archived: boolean) => {
    dispatch({ type: 'update', id, patch: { archived } });
  }, []);

  const deleteHabit = useCallback(async (id: string) => {
    const current = stateRef.current.habits.find((h) => h.id === id);
    if (current?.reminderId) await cancelReminder(current.reminderId);
    dispatch({ type: 'delete', id });
  }, []);

  const setReminder = useCallback(async (id: string, time: string | null): Promise<boolean> => {
    const current = stateRef.current.habits.find((h) => h.id === id);
    if (!current) return false;
    await cancelReminder(current.reminderId);
    let reminderId: string | null = null;
    if (time) {
      const granted = await ensurePermission();
      if (!granted) return false;
      reminderId = await scheduleHabitReminder({
        habitId: id,
        habitName: current.name,
        emoji: current.emoji,
        time,
      });
      if (!reminderId) return false;
    }
    dispatch({ type: 'update', id, patch: { reminder: time, reminderId } });
    return time !== null;
  }, []);

  const setValue = useCallback((id: string, value: number, key: string = todayKey()) => {
    dispatch({ type: 'setValue', id, key, value });
  }, []);

  const bumpValue = useCallback(
    (id: string, delta: number) => {
      const habit = stateRef.current.habits.find((h) => h.id === id);
      if (!habit) return;
      const key = todayKey();
      const current = stateRef.current.logs[id]?.[key] ?? 0;
      dispatch({ type: 'setValue', id, key, value: current + delta });
    },
    [],
  );

  const checkIn = useCallback((id: string) => {
    const habit = stateRef.current.habits.find((h) => h.id === id);
    if (!habit) return;
    const key = todayKey();
    const current = stateRef.current.logs[id]?.[key] ?? 0;
    const goal = habit.kind === 'check' ? 1 : Math.max(2, habit.goal);
    // Tap toggles completion: a completed day resets, otherwise jump to the goal.
    const next = current >= goal ? 0 : goal;
    dispatch({ type: 'setValue', id, key, value: next });
  }, []);

  const clearDay = useCallback((id: string, key: string = todayKey()) => {
    dispatch({ type: 'clearDay', id, key });
  }, []);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    dispatch({ type: 'settings', patch });
  }, []);

  const refreshNotificationPermission = useCallback(async () => {
    const granted = await ensurePermission();
    dispatch({ type: 'settings', patch: { notificationsEnabled: granted } });
  }, []);

  const loadDemoData = useCallback(async () => {
    const seeded = seedState();
    dispatch({ type: 'hydrate', state: { ...seeded, settings: stateRef.current.settings } });
  }, []);

  const resetEverything = useCallback(async () => {
    await cancelAllReminders();
    await clearState();
    dispatch({ type: 'reset' });
  }, []);

  const value = useMemo<HabitContextValue>(
    () => ({
      state,
      ready,
      createHabit,
      updateHabit,
      setArchived,
      deleteHabit,
      setReminder,
      setValue,
      bumpValue,
      checkIn,
      clearDay,
      updateSettings,
      refreshNotificationPermission,
      loadDemoData,
      resetEverything,
    }),
    [
      state,
      ready,
      createHabit,
      updateHabit,
      setArchived,
      deleteHabit,
      setReminder,
      setValue,
      bumpValue,
      checkIn,
      clearDay,
      updateSettings,
      refreshNotificationPermission,
      loadDemoData,
      resetEverything,
    ],
  );

  return <HabitContext.Provider value={value}>{children}</HabitContext.Provider>;
}
