import { Habit, Logs } from '../types';
import { filterOptions } from '../constants';

export type RootStackParamList = {
  Tabs: undefined;
  HabitDetail: { habitId: string };
  AddEditHabit: { habitId?: string };
};

export type TabParamList = {
  Today: undefined;
  Habits: undefined;
  Stats: undefined;
  Settings: undefined;
};

/** Text search across habit name, emoji and unit. */
export function matchesQuery(habit: Habit, query: string): boolean {
  const q = query.trim().toLowerCase();
  if (!q) return true;
  return (
    habit.name.toLowerCase().includes(q) ||
    habit.emoji.includes(q) ||
    habit.unit.toLowerCase().includes(q)
  );
}

export function filterHabits(habits: Habit[], filter: string, query: string): Habit[] {
  return habits.filter((habit) => {
    if (filter === filterOptions[1] && habit.archived) return false;
    if (filter === filterOptions[2] && !habit.archived) return false;
    return matchesQuery(habit, query);
  });
}

/** Habit id -> the day's value. Convenience for list rendering. */
export function valueMap(habits: Habit[], logs: Logs, key: string): Record<string, number> {
  const out: Record<string, number> = {};
  habits.forEach((habit) => {
    const v = logs[habit.id]?.[key];
    out[habit.id] = typeof v === 'number' ? v : 0;
  });
  return out;
}
