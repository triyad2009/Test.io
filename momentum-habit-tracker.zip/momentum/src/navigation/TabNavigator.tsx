import React from 'react';
import { Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { HabitsScreen } from '../screens/HabitsScreen';
import { SettingsScreen } from '../screens/SettingsScreen';
import { StatsScreen } from '../screens/StatsScreen';
import { TodayScreen } from '../screens/TodayScreen';
import { Palette } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';
import { TabParamList } from './types';

const Tab = createBottomTabNavigator<TabParamList>();

type IconName = keyof typeof Ionicons.glyphMap;

const ICONS: Record<keyof TabParamList, { on: IconName; off: IconName }> = {
  Today: { on: 'today', off: 'today-outline' },
  Habits: { on: 'list', off: 'list-outline' },
  Stats: { on: 'stats-chart', off: 'stats-chart-outline' },
  Settings: { on: 'settings', off: 'settings-outline' },
};

export function TabNavigator() {
  const { palette, isDark } = useAppTheme();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: palette.primary,
        tabBarInactiveTintColor: palette.textFaint,
        tabBarStyle: {
          backgroundColor: palette.tabBar,
          borderTopColor: palette.border,
          height: 62,
          paddingBottom: 8,
          paddingTop: 6,
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: '700' },
        tabBarIcon: ({ focused, color, size }) => {
          const names = ICONS[route.name];
          return <Ionicons name={focused ? names.on : names.off} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen
        name="Today"
        component={TodayScreen}
        options={{ tabBarLabel: 'Today', tabBarAccessibilityLabel: 'Today tab' }}
      />
      <Tab.Screen name="Habits" component={HabitsScreen} options={{ tabBarLabel: 'Habits' }} />
      <Tab.Screen name="Stats" component={StatsScreen} options={{ tabBarLabel: 'Stats' }} />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{ tabBarLabel: 'Settings' }}
      />
    </Tab.Navigator>
  );
}

// Suppress unused-import lint for the isDark flag consumers may want later.
export type TabNavigatorPalette = Palette;
export const _tabText = Text;
