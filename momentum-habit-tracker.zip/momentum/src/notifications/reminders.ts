import { Platform } from 'react-native';

/**
 * Local home-screen reminders.
 *
 * expo-notifications is required lazily and every call is guarded, so the app still
 * runs on platforms/builds where the native module is unavailable (web preview, Expo Go).
 * The module exposes a subset of this API depending on SDK — we feature-detect.
 */

type AnyObj = Record<string, any>;

let handlerReady = false;
let cached: AnyObj | null | undefined;

function isSupported(): boolean {
  return Platform.OS === 'ios' || Platform.OS === 'android';
}

function module(): AnyObj | null {
  if (!isSupported()) return null;
  if (cached !== undefined) return cached;
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require('expo-notifications') as AnyObj;
    cached = mod && typeof mod.scheduleNotificationAsync === 'function' ? mod : null;
  } catch {
    cached = null;
  }
  return cached;
}

export async function initNotifications(): Promise<boolean> {
  const N = module();
  if (!N) return false;
  if (!handlerReady && N.setNotificationHandler) {
    try {
      N.setNotificationHandler({
        handleNotification: async () => ({
          shouldShowAlert: true,
          shouldShowBanner: true,
          shouldShowList: true,
          shouldPlaySound: false,
          shouldSetBadge: false,
        }),
      });
      handlerReady = true;
    } catch {
      return false;
    }
  }
  return true;
}

/** Asks for permission. Returns true when we may post notifications. */
export async function ensurePermission(): Promise<boolean> {
  const N = module();
  if (!N) return false;
  try {
    const current = await N.getPermissionsAsync();
    if (current && current.granted) return true;
    const asked = await N.requestPermissionsAsync();
    return asked ? asked.granted === true : false;
  } catch {
    return false;
  }
}

export async function getPermissionStatus(): Promise<'granted' | 'denied' | 'unsupported'> {
  const N = module();
  if (!N) return 'unsupported';
  try {
    const current = await N.getPermissionsAsync();
    return current && current.granted ? 'granted' : 'denied';
  } catch {
    return 'unsupported';
  }
}

function parseTime(hhmm: string): { hour: number; minute: number } | null {
  const match = /^(\d{1,2}):(\d{2})$/.exec(hhmm);
  if (!match) return null;
  const hour = parseInt(match[1], 10);
  const minute = parseInt(match[2], 10);
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
  return { hour, minute };
}

/**
 * Schedules a repeating daily reminder for a habit.
 * Returns the OS notification id, or null when scheduling is unavailable.
 */
export async function scheduleHabitReminder(params: {
  habitId: string;
  habitName: string;
  emoji: string;
  time: string;
}): Promise<string | null> {
  const N = module();
  if (!N) return null;
  const parsed = parseTime(params.time);
  if (!parsed) return null;

  const granted = await ensurePermission();
  if (!granted) return null;

  try {
    const id = await N.scheduleNotificationAsync({
      content: {
        title: `${params.emoji} ${params.habitName}`,
        body: 'Time to keep the streak alive.',
        data: { habitId: params.habitId },
        sound: false,
      },
      trigger: {
        type: 'daily',
        hour: parsed.hour,
        minute: parsed.minute,
        repeats: true,
      },
    });
    return typeof id === 'string' ? id : null;
  } catch {
    return null;
  }
}

export async function cancelReminder(reminderId: string | null | undefined): Promise<void> {
  if (!reminderId) return;
  const N = module();
  if (!N) return;
  try {
    await N.cancelScheduledNotificationAsync(reminderId);
  } catch {
    // Already fired or removed — nothing to do.
  }
}

export async function cancelAllReminders(): Promise<void> {
  const N = module();
  if (!N) return;
  try {
    await N.cancelAllScheduledNotificationsAsync();
  } catch {
    // ignore
  }
}

export async function scheduledCount(): Promise<number> {
  const N = module();
  if (!N) return 0;
  try {
    const list = await N.getAllScheduledNotificationsAsync();
    return Array.isArray(list) ? list.length : 0;
  } catch {
    return 0;
  }
}
