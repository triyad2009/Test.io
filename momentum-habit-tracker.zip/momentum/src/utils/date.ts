export const DAY_MS = 24 * 60 * 60 * 1000;

/** Local-calendar date key, e.g. "2026-09-21". */
export function toKey(d: Date): string {
  const y = d.getFullYear();
  const m = `${d.getMonth() + 1}`.padStart(2, '0');
  const day = `${d.getDate()}`.padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/** Parses a key into a local Date anchored at noon (DST-safe). */
export function fromKey(key: string): Date {
  const parts = key.split('-').map((p) => parseInt(p, 10));
  const y = parts[0] || 1970;
  const m = parts[1] || 1;
  const d = parts[2] || 1;
  return new Date(y, m - 1, d, 12, 0, 0, 0);
}

export function todayKey(): string {
  return toKey(new Date());
}

export function addDays(key: string, delta: number): string {
  const d = fromKey(key);
  d.setDate(d.getDate() + delta);
  return toKey(d);
}

/** Whole days between two keys (b - a). */
export function diffDays(a: string, b: string): number {
  return Math.round((fromKey(b).getTime() - fromKey(a).getTime()) / DAY_MS);
}

/** Oldest-first list of the last `count` days ending at `endKey`. */
export function lastNDays(count: number, endKey: string = todayKey()): string[] {
  const out: string[] = [];
  for (let i = count - 1; i >= 0; i -= 1) out.push(addDays(endKey, -i));
  return out;
}

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

export function weekdayShort(key: string): string {
  return WEEKDAYS[fromKey(key).getDay()];
}

export function weekdayIndex(key: string): number {
  return fromKey(key).getDay();
}

export function dayNumber(key: string): number {
  return fromKey(key).getDate();
}

export function formatLongDate(key: string): string {
  const d = fromKey(key);
  return `${WEEKDAYS[d.getDay()]}, ${MONTHS[d.getMonth()]} ${d.getDate()}`;
}

export function formatMonthShort(key: string): string {
  return MONTHS[fromKey(key).getMonth()].slice(0, 3);
}

export function formatMonthYear(key: string): string {
  const d = fromKey(key);
  return `${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

export function greeting(hour: number): string {
  if (hour < 5) return 'Still up';
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

/** "07:30" -> "7:30 AM" */
export function formatTime(hhmm: string): string {
  const [h, m] = hhmm.split(':').map((p) => parseInt(p, 10));
  const suffix = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${hour12}:${`${m}`.padStart(2, '0')} ${suffix}`;
}
