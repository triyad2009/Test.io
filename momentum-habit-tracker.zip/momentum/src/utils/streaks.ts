import { Habit, HabitStats, Logs } from '../types';
import { addDays, diffDays, todayKey } from './date';

/** Hard cap so a corrupt createdAt can never spin the streak loops forever. */
const MAX_SCAN_DAYS = 3650;

export function valueFor(habit: Habit, logs: Logs, key: string): number {
  const day = logs[habit.id];
  if (!day) return 0;
  const value = day[key];
  return typeof value === 'number' && Number.isFinite(value) ? value : 0;
}

/** A day counts as complete when it hits the habit's daily goal. */
export function isComplete(value: number, habit: Habit): boolean {
  return value >= Math.max(1, habit.goal);
}

export function isDoneOn(habit: Habit, logs: Logs, key: string): boolean {
  return isComplete(valueFor(habit, logs, key), habit);
}

/** Zero progress towards the goal, clamped to 0..1. */
export function dayProgress(habit: Habit, logs: Logs, key: string): number {
  const goal = Math.max(1, habit.goal);
  return Math.min(1, Math.max(0, valueFor(habit, logs, key) / goal));
}

/** A habit is "due" on a day if the day is on/after creation and it isn't archived. */
export function isDueOn(habit: Habit, key: string): boolean {
  if (habit.archived) return false;
  return diffDays(habit.createdAt, key) >= 0;
}

/**
 * Consecutive complete days ending today or yesterday.
 * Yesterday counts so an untouched today never visually breaks a live streak.
 */
export function currentStreak(habit: Habit, logs: Logs, endKey: string = todayKey()): number {
  let cursor = endKey;
  if (!isDoneOn(habit, logs, cursor)) {
    cursor = addDays(cursor, -1);
    if (!isDoneOn(habit, logs, cursor)) return 0;
  }
  let streak = 0;
  let guard = 0;
  while (guard < MAX_SCAN_DAYS) {
    guard += 1;
    if (diffDays(habit.createdAt, cursor) < 0) break;
    if (!isDoneOn(habit, logs, cursor)) break;
    streak += 1;
    cursor = addDays(cursor, -1);
  }
  return streak;
}

/**
 * Longest run of complete days in the tracked window.
 *
 * Walks BACKWARDS from `endKey`, not forwards from `createdAt`: with the scan
 * capped at MAX_SCAN_DAYS, a forward walk would never reach recent days for a
 * very old habit and would wrongly report a best streak of 0.
 */
export function bestStreak(habit: Habit, logs: Logs, endKey: string = todayKey()): number {
  const span = Math.min(Math.max(0, diffDays(habit.createdAt, endKey)) + 1, MAX_SCAN_DAYS);
  let best = 0;
  let run = 0;
  for (let i = 0; i < span; i += 1) {
    const key = addDays(endKey, -i);
    if (isDoneOn(habit, logs, key)) {
      run += 1;
      if (run > best) best = run;
    } else {
      run = 0;
    }
  }
  return best;
}

export function totalCompletions(habit: Habit, logs: Logs): number {
  const day = logs[habit.id];
  if (!day) return 0;
  let total = 0;
  Object.keys(day).forEach((key) => {
    if (isComplete(day[key], habit)) total += 1;
  });
  return total;
}

/** Fraction of tracked days that hit the goal, over the last `days` days. */
export function completionRate(
  habit: Habit,
  logs: Logs,
  days = 30,
  endKey: string = todayKey(),
): number {
  let due = 0;
  let done = 0;
  for (let i = 0; i < days; i += 1) {
    const key = addDays(endKey, -i);
    if (diffDays(habit.createdAt, key) < 0) break;
    due += 1;
    if (isDoneOn(habit, logs, key)) done += 1;
  }
  if (due === 0) return 0;
  return done / due;
}

export function statsFor(habit: Habit, logs: Logs, endKey: string = todayKey()): HabitStats {
  const trackedDays = Math.min(Math.max(0, diffDays(habit.createdAt, endKey)) + 1, MAX_SCAN_DAYS);
  const todayValue = valueFor(habit, logs, endKey);
  return {
    current: currentStreak(habit, logs, endKey),
    best: bestStreak(habit, logs, endKey),
    total: totalCompletions(habit, logs),
    completionRate: completionRate(habit, logs, 30, endKey),
    trackedDays,
    todayValue,
    todayDone: isComplete(todayValue, habit),
  };
}

/** 0..1 completion ratio across every active habit for a single day. */
export function dayCompletion(habits: Habit[], logs: Logs, key: string): { done: number; due: number; ratio: number } {
  let due = 0;
  let done = 0;
  habits.forEach((habit) => {
    if (!isDueOn(habit, key)) return;
    due += 1;
    if (isDoneOn(habit, logs, key)) done += 1;
  });
  return { done, due, ratio: due === 0 ? 0 : done / due };
}

/** Per-day completion ratios for a list of keys (oldest first). */
export function completionSeries(habits: Habit[], logs: Logs, keys: string[]): number[] {
  return keys.map((key) => dayCompletion(habits, logs, key).ratio);
}

/** Which weekday (0=Sun) you complete most often. Returns ratio per weekday. */
export function weekdayPattern(habits: Habit[], logs: Logs, days: number, endKey: string = todayKey()): number[] {
  const sums = [0, 0, 0, 0, 0, 0, 0];
  const counts = [0, 0, 0, 0, 0, 0, 0];
  for (let i = 0; i < days; i += 1) {
    const key = addDays(endKey, -i);
    const { due, ratio } = dayCompletion(habits, logs, key);
    if (due === 0) continue;
    const idx = new Date(
      parseInt(key.slice(0, 4), 10),
      parseInt(key.slice(5, 7), 10) - 1,
      parseInt(key.slice(8, 10), 10),
    ).getDay();
    sums[idx] += ratio;
    counts[idx] += 1;
  }
  return sums.map((sum, i) => (counts[i] === 0 ? 0 : sum / counts[i]));
}
