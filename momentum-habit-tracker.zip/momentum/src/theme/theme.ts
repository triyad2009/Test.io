export interface Palette {
  background: string;
  surface: string;
  surfaceAlt: string;
  border: string;
  text: string;
  textMuted: string;
  textFaint: string;
  primary: string;
  primarySoft: string;
  onPrimary: string;
  success: string;
  danger: string;
  warning: string;
  tabBar: string;
  shadow: string;
  track: string;
}

export const lightPalette: Palette = {
  background: '#F5F6FA',
  surface: '#FFFFFF',
  surfaceAlt: '#EEF0F7',
  border: '#E2E5EF',
  text: '#12131A',
  textMuted: '#5B6070',
  textFaint: '#8E93A6',
  primary: '#4F46E5',
  primarySoft: '#E5E4FB',
  onPrimary: '#FFFFFF',
  success: '#10B981',
  danger: '#EF4444',
  warning: '#F59E0B',
  tabBar: '#FFFFFF',
  shadow: '#0F172A',
  track: '#E2E5EF',
};

export const darkPalette: Palette = {
  background: '#0B0C11',
  surface: '#15171F',
  surfaceAlt: '#1D2029',
  border: '#282C38',
  text: '#F4F6FB',
  textMuted: '#A2A8BA',
  textFaint: '#727889',
  primary: '#7C7BFF',
  primarySoft: '#26254A',
  onPrimary: '#FFFFFF',
  success: '#34D399',
  danger: '#F87171',
  warning: '#FBBF24',
  tabBar: '#11131A',
  shadow: '#000000',
  track: '#282C38',
};

export const radius = { sm: 10, md: 16, lg: 22, xl: 30, pill: 999 };
export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 22, xxl: 32 };

export function isHexDark(hex: string): boolean {
  const raw = hex.replace('#', '');
  const full = raw.length === 3 ? raw.split('').map((c) => c + c).join('') : raw;
  const r = parseInt(full.slice(0, 2), 16);
  const g = parseInt(full.slice(2, 4), 16);
  const b = parseInt(full.slice(4, 6), 16);
  // Relative luminance (sRGB, simplified) — used to pick readable text on a colour chip.
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance < 0.6;
}
