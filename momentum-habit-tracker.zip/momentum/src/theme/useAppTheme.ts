import { useColorScheme } from 'react-native';

import { darkPalette, lightPalette, Palette } from './theme';
import { useHabits } from '../hooks/useHabits';

/** Resolves the active palette from the user's theme setting + OS appearance. */
export function useAppTheme(): { palette: Palette; isDark: boolean } {
  const system = useColorScheme();
  const { state } = useHabits();
  const mode = state.settings.themeMode;
  const isDark = mode === 'system' ? system === 'dark' : mode === 'dark';
  return { palette: isDark ? darkPalette : lightPalette, isDark };
}
