import AsyncStorage from '@react-native-async-storage/async-storage';

import { Habit, HabitKind, Logs, PersistedState, Settings, ThemeMode } from '../types';

export const STORAGE_KEY = 'momentum.state.v1';
export const STATE_VERSION = 1;

export const defaultSettings: Settings = {
  themeMode: 'system',
  notificationsEnabled: false,
  displayName: '',
};

const KIND_SET: HabitKind[] = ['check', 'count'];
const THEME_SET: ThemeMode[] = ['system', 'light', 'dark'];

function asNumber(value: unknown, fallback = 0): number {
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback;
}

function asString(value: unknown, fallback = ''): string {
  return typeof value === 'string' ? value : fallback;
}

/** "HH:mm" or null. Anything malformed is dropped rather than crashing a screen. */
function asTime(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const match = /^(\d{1,2}):(\d{2})$/.exec(value);
  if (!match) return null;
  const h = parseInt(match[1], 10);
  const m = parseInt(match[2], 10);
  if (h < 0 || h > 23 || m < 0 || m > 59) return null;
  return `${`${h}`.padStart(2, '0')}:${`${m}`.padStart(2, '0')}`;
}

function sanitizeHabit(raw: unknown): Habit | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  const id = asString(r.id);
  const name = asString(r.name).trim();
  if (!id || !name) return null;
  const kind = KIND_SET.includes(r.kind as HabitKind) ? (r.kind as HabitKind) : 'check';
  const goalRaw = Math.round(asNumber(r.goal, 1));
  return {
    id,
    name: name.slice(0, 60),
    emoji: asString(r.emoji, '🎯') || '🎯',
    color: /^#[0-9a-fA-F]{6}$/.test(asString(r.color)) ? asString(r.color) : '#4F46E5',
    kind,
    goal: kind === 'check' ? 1 : Math.min(999, Math.max(2, goalRaw)),
    unit: asString(r.unit, '').slice(0, 16),
    createdAt: /^\d{4}-\d{2}-\d{2}$/.test(asString(r.createdAt))
      ? asString(r.createdAt)
      : new Date().toISOString().slice(0, 10),
    reminder: asTime(r.reminder),
    reminderId: typeof r.reminderId === 'string' ? r.reminderId : null,
    archived: r.archived === true,
  };
}

function sanitizeLogs(raw: unknown, habits: Habit[]): Logs {
  const out: Logs = {};
  if (!raw || typeof raw !== 'object') return out;
  const source = raw as Record<string, unknown>;
  habits.forEach((habit) => {
    const dayRecord = source[habit.id];
    if (!dayRecord || typeof dayRecord !== 'object') return;
    const cleaned: Record<string, number> = {};
    Object.entries(dayRecord as Record<string, unknown>).forEach(([key, value]) => {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) return;
      const num = Math.round(asNumber(value, 0));
      if (num <= 0) return;
      cleaned[key] = Math.min(9999, num);
    });
    if (Object.keys(cleaned).length > 0) out[habit.id] = cleaned;
  });
  return out;
}

function sanitizeSettings(raw: unknown): Settings {
  if (!raw || typeof raw !== 'object') return { ...defaultSettings };
  const r = raw as Record<string, unknown>;
  return {
    themeMode: THEME_SET.includes(r.themeMode as ThemeMode) ? (r.themeMode as ThemeMode) : 'system',
    notificationsEnabled: r.notificationsEnabled === true,
    displayName: asString(r.displayName, '').slice(0, 40),
  };
}

/** Coerces arbitrary persisted JSON into a valid state object. Never throws. */
export function sanitizeState(raw: unknown): PersistedState {
  if (!raw || typeof raw !== 'object') {
    return { version: STATE_VERSION, habits: [], logs: {}, settings: { ...defaultSettings } };
  }
  const r = raw as Record<string, unknown>;
  const habits = Array.isArray(r.habits)
    ? (r.habits.map(sanitizeHabit).filter(Boolean) as Habit[])
    : [];
  return {
    version: STATE_VERSION,
    habits,
    logs: sanitizeLogs(r.logs, habits),
    settings: sanitizeSettings(r.settings),
  };
}

export async function loadState(): Promise<PersistedState | null> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return sanitizeState(JSON.parse(raw));
  } catch {
    return null;
  }
}

export async function saveState(state: PersistedState): Promise<void> {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Persistence failures must never break an interaction mid-tap.
  }
}

export async function clearState(): Promise<void> {
  try {
    await AsyncStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}
