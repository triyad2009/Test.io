import { Habit, Logs, PersistedState } from '../types';
import { addDays, toKey, todayKey } from '../utils/date';
import { STATE_VERSION, defaultSettings } from '../storage/persistence';

export const starterHabits: Habit[] = [
  {
    id: 'h_starter_water',
    name: 'Drink water',
    emoji: '💧',
    color: '#0EA5E9',
    kind: 'count',
    goal: 8,
    unit: 'glasses',
    createdAt: addDays(todayKey(), -24),
    reminder: '09:00',
    reminderId: null,
    archived: false,
  },
  {
    id: 'h_starter_read',
    name: 'Read 20 pages',
    emoji: '📖',
    color: '#8B5CF6',
    kind: 'check',
    goal: 1,
    unit: '',
    createdAt: addDays(todayKey(), -24),
    reminder: '21:30',
    reminderId: null,
    archived: false,
  },
  {
    id: 'h_starter_move',
    name: 'Move your body',
    emoji: '🏃',
    color: '#10B981',
    kind: 'check',
    goal: 1,
    unit: '',
    createdAt: addDays(todayKey(), -20),
    reminder: null,
    reminderId: null,
    archived: false,
  },
];

/** Deterministic pseudo-random so the demo data looks organic but is reproducible. */
function mix(seed: number): number {
  const x = Math.sin(seed * 12.9898) * 43758.5453;
  return x - Math.floor(x);
}

/**
 * First-run seed: a few habits with a realistic history so the dashboard and
 * charts are meaningful the moment the app opens.
 */
export function seedState(): PersistedState {
  const logs: Logs = {};
  const today = toKey(new Date());

  starterHabits.forEach((habit, habitIndex) => {
    const days = Math.max(1, daySpan(habit.createdAt, today));
    const day: Record<string, number> = {};
    for (let i = days - 1; i >= 0; i -= 1) {
      const key = addDays(today, -i);
      const noise = mix(i * 3.7 + habitIndex * 11.3);
      if (habit.kind === 'count') {
        const value = i < 3 ? 6 + Math.round(noise * 3) : Math.round(noise * habit.goal * 1.35);
        if (value > 0) day[key] = Math.min(habit.goal + 3, value);
      } else if (noise > 0.28) {
        day[key] = 1;
      }
    }
    logs[habit.id] = day;
  });

  return {
    version: STATE_VERSION,
    habits: starterHabits,
    logs,
    settings: { ...defaultSettings },
  };
}

function daySpan(from: string, to: string): number {
  const a = new Date(`${from}T12:00:00`).getTime();
  const b = new Date(`${to}T12:00:00`).getTime();
  return Math.round((b - a) / 86400000) + 1;
}
