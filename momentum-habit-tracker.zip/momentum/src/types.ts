export type HabitKind = 'check' | 'count';

export interface Habit {
  id: string;
  name: string;
  emoji: string;
  color: string;
  kind: HabitKind;
  /** Target per day. Always 1 for `check` habits. */
  goal: number;
  /** Label shown for `count` habits, e.g. "glasses". */
  unit: string;
  /** Local date key (YYYY-MM-DD) the habit was created on. */
  createdAt: string;
  /** "HH:mm" local time, or null when no reminder is set. */
  reminder: string | null;
  /** OS-level scheduled notification id, kept so we can cancel/replace it. */
  reminderId: string | null;
  archived: boolean;
}

/** habitId -> dateKey -> value (1 for a check, arbitrary integer for a count) */
export type Logs = Record<string, Record<string, number>>;

export type ThemeMode = 'system' | 'light' | 'dark';

export interface Settings {
  themeMode: ThemeMode;
  notificationsEnabled: boolean;
  displayName: string;
}

export interface HabitStats {
  current: number;
  best: number;
  total: number;
  /** 0..1 ratio of completed days over the tracked window. */
  completionRate: number;
  trackedDays: number;
  todayValue: number;
  todayDone: boolean;
}

export interface PersistedState {
  version: number;
  habits: Habit[];
  logs: Logs;
  settings: Settings;
}
