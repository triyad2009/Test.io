import React, { useMemo, useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import { AppButton, SectionTitle } from '../components/AppButton';
import { Card } from '../components/EmptyState';
import { ColorSwatch, Stepper, Swatch } from '../components/Swatch';
import { habitColors, habitEmojis, reminderPresets } from '../constants';
import { useHabits } from '../hooks/useHabits';
import { RootStackParamList } from '../navigation/types';
import { HabitKind } from '../types';
import { Palette, radius, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';
import { formatTime } from '../utils/date';

type Props = NativeStackScreenProps<RootStackParamList, 'AddEditHabit'>;

export function AddEditHabitScreen({ route, navigation }: Props) {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);
  const { state, createHabit, updateHabit } = useHabits();
  const editingId = route.params?.habitId;
  const existing = useMemo(
    () => state.habits.find((h) => h.id === editingId),
    [state.habits, editingId],
  );

  const [name, setName] = useState(existing?.name ?? '');
  const [emoji, setEmoji] = useState(existing?.emoji ?? habitEmojis[0]);
  const [color, setColor] = useState(existing?.color ?? habitColors[0]);
  const [kind, setKind] = useState<HabitKind>(existing?.kind ?? 'check');
  const [goal, setGoal] = useState(existing?.goal && existing.goal > 1 ? existing.goal : 8);
  const [unit, setUnit] = useState(existing?.unit ?? '');
  const [reminder, setReminder] = useState<string | null>(existing?.reminder ?? null);
  const [saving, setSaving] = useState(false);

  const isEditing = Boolean(existing);

  const onSave = async () => {
    const trimmed = name.trim();
    if (!trimmed) {
      Alert.alert('Name required', 'Give your habit a short, clear name.');
      return;
    }
    setSaving(true);
    try {
      if (existing) {
        await updateHabit(existing.id, { name: trimmed, emoji, color, kind, goal, unit, reminder });
      } else {
        await createHabit({ name: trimmed, emoji, color, kind, goal, unit, reminder });
      }
      navigation.goBack();
    } finally {
      setSaving(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: palette.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        style={styles.container}
        contentContainerStyle={{ paddingTop: spacing.xl, paddingBottom: spacing.xxl * 2 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.preview}>
          <View style={[styles.previewEmoji, { backgroundColor: `${color}22` }]}>
            <Text style={{ fontSize: 34 }}>{emoji}</Text>
          </View>
          <Text style={styles.previewName}>{name.trim() || 'New habit'}</Text>
          <Text style={styles.previewMeta}>
            {kind === 'count' ? `${goal}${unit ? ` ${unit}` : ''} per day` : 'Once a day'}
            {reminder ? ` · ${formatTime(reminder)}` : ''}
          </Text>
        </View>

        <SectionTitle>Name</SectionTitle>
        <TextInput
          value={name}
          onChangeText={setName}
          placeholder="e.g. Read 20 pages"
          placeholderTextColor={palette.textFaint}
          style={styles.input}
          maxLength={60}
          accessibilityLabel="Habit name"
          returnKeyType="done"
        />

        <SectionTitle>Icon</SectionTitle>
        <View style={styles.grid}>
          {habitEmojis.map((option) => (
            <Swatch
              key={option}
              name={option}
              emoji={option}
              color="transparent"
              selected={emoji === option}
              onPress={() => setEmoji(option)}
            />
          ))}
        </View>

        <SectionTitle>Colour</SectionTitle>
        <View style={styles.grid}>
          {habitColors.map((option) => (
            <ColorSwatch
              key={option}
              color={option}
              selected={color === option}
              onPress={() => setColor(option)}
            />
          ))}
        </View>

        <SectionTitle>Type</SectionTitle>
        <View style={styles.segment}>
          {(['check', 'count'] as HabitKind[]).map((option) => (
            <Pressable
              key={option}
              accessibilityRole="button"
              accessibilityState={{ selected: kind === option }}
              onPress={() => setKind(option)}
              style={[
                styles.segmentItem,
                kind === option && { backgroundColor: palette.primary },
              ]}
            >
              <Text
                style={[
                  styles.segmentText,
                  { color: kind === option ? palette.onPrimary : palette.textMuted },
                ]}
              >
                {option === 'check' ? 'Simple check' : 'Count goal'}
              </Text>
            </Pressable>
          ))}
        </View>

        {kind === 'count' ? (
          <>
            <SectionTitle>Daily goal</SectionTitle>
            <Card>
              <View style={{ alignItems: 'center' }}>
                <Stepper value={goal} onChange={setGoal} min={2} max={99} suffix={unit || 'times'} />
              </View>
            </Card>

            <SectionTitle>Unit label</SectionTitle>
            <TextInput
              value={unit}
              onChangeText={setUnit}
              placeholder="glasses, pages, km…"
              placeholderTextColor={palette.textFaint}
              style={styles.input}
              maxLength={16}
              accessibilityLabel="Unit label"
              returnKeyType="done"
            />
          </>
        ) : null}

        <SectionTitle>Reminder</SectionTitle>
        <View style={styles.grid}>
          {reminderPresets.map((preset) => (
            <Pressable
              key={preset.label}
              accessibilityRole="button"
              accessibilityState={{ selected: reminder === preset.value }}
              onPress={() => setReminder(preset.value)}
              style={[
                styles.timeChip,
                reminder === preset.value && {
                  backgroundColor: palette.primarySoft,
                  borderColor: palette.primary,
                },
              ]}
            >
              <Text
                style={[
                  styles.timeText,
                  { color: reminder === preset.value ? palette.primary : palette.textMuted },
                ]}
              >
                {preset.label}
              </Text>
            </Pressable>
          ))}
        </View>

        <View style={{ marginTop: spacing.xxl, gap: spacing.sm }}>
          <AppButton
            label={saving ? 'Saving…' : isEditing ? 'Save changes' : 'Create habit'}
            onPress={onSave}
            disabled={saving}
          />
          <AppButton label="Cancel" variant="ghost" onPress={() => navigation.goBack()} />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: palette.background, paddingHorizontal: spacing.lg },
    preview: { alignItems: 'center' },
    previewEmoji: {
      width: 76,
      height: 76,
      borderRadius: radius.xl,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: spacing.md,
    },
    previewName: { color: palette.text, fontSize: 20, fontWeight: '800' },
    previewMeta: { color: palette.textMuted, fontSize: 13, marginTop: spacing.xs },
    input: {
      backgroundColor: palette.surface,
      borderRadius: radius.md,
      borderWidth: 1,
      borderColor: palette.border,
      paddingHorizontal: spacing.md,
      paddingVertical: spacing.md,
      color: palette.text,
      fontSize: 15,
    },
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
    segment: {
      flexDirection: 'row',
      backgroundColor: palette.surfaceAlt,
      borderRadius: radius.pill,
      padding: 4,
      gap: 4,
    },
    segmentItem: {
      flex: 1,
      paddingVertical: spacing.md,
      borderRadius: radius.pill,
      alignItems: 'center',
    },
    segmentText: { fontSize: 14, fontWeight: '700' },
    timeChip: {
      paddingHorizontal: spacing.md,
      paddingVertical: spacing.sm,
      borderRadius: radius.pill,
      borderWidth: 1,
      borderColor: palette.border,
      backgroundColor: palette.surface,
    },
    timeText: { fontSize: 13, fontWeight: '600' },
  });
}
