import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Linking, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { AppButton, Pill, SectionTitle } from '../components/AppButton';
import { Card, Divider } from '../components/EmptyState';
import { useHabits } from '../hooks/useHabits';
import { Palette, radius, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';
import { ThemeMode } from '../types';
import { getPermissionStatus, scheduledCount } from '../notifications/reminders';

const MODES: { label: string; value: ThemeMode }[] = [
  { label: 'System', value: 'system' },
  { label: 'Light', value: 'light' },
  { label: 'Dark', value: 'dark' },
];

export function SettingsScreen() {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);
  const insets = useSafeAreaInsets();
  const {
    state,
    updateSettings,
    refreshNotificationPermission,
    loadDemoData,
    resetEverything,
  } = useHabits();

  const [permission, setPermission] = useState<'granted' | 'denied' | 'unsupported'>('unsupported');
  const [scheduled, setScheduled] = useState(0);

  const refresh = useCallback(async () => {
    const status = await getPermissionStatus();
    setPermission(status);
    setScheduled(await scheduledCount());
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh, state.habits]);

  const activeCount = state.habits.filter((h) => !h.archived).length;
  const archivedCount = state.habits.filter((h) => h.archived).length;
  const totalLoggedDays = Object.values(state.logs).reduce(
    (sum, days) => sum + Object.keys(days).length,
    0,
  );

  const onToggleNotifications = async (next: boolean) => {
    updateSettings({ notificationsEnabled: next });
    if (next) await refreshNotificationPermission();
    refresh();
  };

  const onReset = () => {
    Alert.alert(
      'Erase all data?',
      'This deletes every habit, log and setting on this device. It cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Erase everything',
          style: 'destructive',
          onPress: async () => {
            await resetEverything();
            refresh();
          },
        },
      ],
    );
  };

  const onLoadDemo = () => {
    Alert.alert('Load sample data?', 'This replaces your current habits and logs with demo data.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Load demo',
        onPress: async () => {
          await loadDemoData();
          refresh();
        },
      },
    ]);
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingTop: insets.top + spacing.lg, paddingBottom: spacing.xxl * 2 }}
      showsVerticalScrollIndicator={false}
    >
      <Text style={styles.heading}>Settings</Text>
      <Text style={styles.subheading}>Make Momentum yours</Text>

      <SectionTitle>Profile</SectionTitle>
      <Card>
        <Text style={styles.label}>Display name</Text>
        <TextInput
          value={state.settings.displayName}
          onChangeText={(text) => updateSettings({ displayName: text })}
          placeholder="What should we call you?"
          placeholderTextColor={palette.textFaint}
          style={styles.input}
          maxLength={40}
          accessibilityLabel="Display name"
          returnKeyType="done"
        />
        <Text style={styles.help}>Used only for the greeting on the Today screen.</Text>
      </Card>

      <SectionTitle>Appearance</SectionTitle>
      <Card>
        <Text style={styles.label}>Theme</Text>
        <View style={styles.modeRow}>
          {MODES.map((mode) => (
            <Pill
              key={mode.value}
              label={mode.label}
              active={state.settings.themeMode === mode.value}
              onPress={() => updateSettings({ themeMode: mode.value })}
            />
          ))}
        </View>
        <Text style={styles.help}>
          System follows your device. Light and Dark lock the app to one look.
        </Text>
      </Card>

      <SectionTitle>Notifications</SectionTitle>
      <Card>
        <View style={styles.switchRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.label}>Daily reminders</Text>
            <Text style={styles.help}>
              {permission === 'granted'
                ? `${scheduled} reminder${scheduled === 1 ? '' : 's'} scheduled on this device.`
                : permission === 'denied'
                  ? 'Permission not granted — enable notifications in system settings.'
                  : 'Not supported on this platform or build.'}
            </Text>
          </View>
          <Switch
            value={state.settings.notificationsEnabled}
            onValueChange={onToggleNotifications}
            trackColor={{ true: palette.primary, false: palette.track }}
            accessibilityLabel="Toggle daily reminders"
          />
        </View>
        {permission === 'denied' ? (
          <View style={{ marginTop: spacing.lg }}>
            <AppButton
              label="Open system settings"
              variant="secondary"
              onPress={() => Linking.openSettings()}
            />
          </View>
        ) : null}
      </Card>

      <SectionTitle>Your data</SectionTitle>
      <Card>
        <View style={styles.dataRow}>
          <Text style={styles.label}>Active habits</Text>
          <Text style={styles.value}>{activeCount}</Text>
        </View>
        <Divider />
        <View style={styles.dataRow}>
          <Text style={styles.label}>Archived habits</Text>
          <Text style={styles.value}>{archivedCount}</Text>
        </View>
        <Divider />
        <View style={styles.dataRow}>
          <Text style={styles.label}>Logged days</Text>
          <Text style={styles.value}>{totalLoggedDays}</Text>
        </View>
        <Text style={styles.help}>
          Everything is stored on-device with AsyncStorage. No account, no network, no tracking.
        </Text>
      </Card>

      <SectionTitle>Actions</SectionTitle>
      <View style={{ gap: spacing.sm }}>
        <AppButton label="Reload sample data" variant="secondary" onPress={onLoadDemo} />
        <AppButton label="Erase all data" variant="danger" onPress={onReset} />
      </View>

      <SectionTitle>About</SectionTitle>
      <Card>
        <Text style={styles.label}>Momentum · v1.0.0</Text>
        <Text style={styles.help}>
          A habit tracker built with Expo, React Native and TypeScript. Runs on iOS and Android from
          one codebase.
        </Text>
      </Card>
    </ScrollView>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: palette.background, paddingHorizontal: spacing.lg },
    heading: { color: palette.text, fontSize: 26, fontWeight: '800' },
    subheading: { color: palette.textMuted, fontSize: 13, marginTop: 2 },
    label: { color: palette.text, fontSize: 15, fontWeight: '700' },
    value: { color: palette.text, fontSize: 15, fontWeight: '800' },
    help: { color: palette.textMuted, fontSize: 12.5, marginTop: spacing.sm, lineHeight: 18 },
    input: {
      backgroundColor: palette.surfaceAlt,
      borderRadius: radius.md,
      borderWidth: 1,
      borderColor: palette.border,
      paddingHorizontal: spacing.md,
      paddingVertical: spacing.md,
      color: palette.text,
      fontSize: 15,
      marginTop: spacing.md,
    },
    modeRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.md },
    switchRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg },
    dataRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  });
}
