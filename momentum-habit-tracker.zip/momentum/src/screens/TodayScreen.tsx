import React, { useMemo } from 'react';
import {
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { AppButton, Pill, SectionTitle } from '../components/AppButton';
import { EmptyState } from '../components/EmptyState';
import { HabitCard } from '../components/HabitCard';
import { ProgressRing } from '../components/ProgressRing';
import { StatTile } from '../components/StatTile';
import { useHabits } from '../hooks/useHabits';
import { RootStackParamList } from '../navigation/types';
import { Palette, radius, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';
import { formatLongDate, greeting, lastNDays, todayKey } from '../utils/date';
import { currentStreak, dayCompletion, isDueOn, weekdayPattern } from '../utils/streaks';

type Props = NativeStackScreenProps<RootStackParamList, 'Tabs'>;

export function TodayScreen({ navigation }: { navigation: Props['navigation'] }) {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);
  const insets = useSafeAreaInsets();
  const {
    state,
    ready,
    checkIn,
    bumpValue,
  } = useHabits();

  const today = todayKey();
  const activeHabits = useMemo(() => state.habits.filter((h) => !h.archived), [state.habits]);
  const dueToday = useMemo(() => activeHabits.filter((h) => isDueOn(h, today)), [activeHabits, today]);

  const completion = useMemo(
    () => dayCompletion(activeHabits, state.logs, today),
    [activeHabits, state.logs, today],
  );

  const weekly = useMemo(() => {
    const keys = lastNDays(7, today);
    return keys.map((key) => dayCompletion(activeHabits, state.logs, key).ratio);
  }, [activeHabits, state.logs, today]);

  const weekAverage = useMemo(
    () => (weekly.length === 0 ? 0 : weekly.reduce((a, b) => a + b, 0) / weekly.length),
    [weekly],
  );

  const pattern = useMemo(
    () => weekdayPattern(activeHabits, state.logs, 28, today),
    [activeHabits, state.logs, today],
  );

  const bestWeekdayIndex = useMemo(() => {
    let idx = -1;
    let best = 0;
    pattern.forEach((value, i) => {
      if (value > best) {
        best = value;
        idx = i;
      }
    });
    return best > 0 ? idx : -1;
  }, [pattern]);

  const hour = new Date().getHours();
  const name = state.settings.displayName.trim();
  const weekdayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const perfectDays = useMemo(() => {
    const keys = lastNDays(30, today);
    return keys.filter((key) => {
      const { due, done } = dayCompletion(activeHabits, state.logs, key);
      return due > 0 && done === due;
    }).length;
  }, [activeHabits, state.logs, today]);

  if (ready && dueToday.length === 0) {
    return (
      <View style={[styles.container, { paddingTop: insets.top + spacing.lg }]}>
        <EmptyState
          emoji="🌱"
          title="No habits yet"
          body="Add your first habit and today's dashboard will start filling up."
        >
          <AppButton label="Create a habit" onPress={() => navigation.navigate('AddEditHabit', {})} />
        </EmptyState>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingTop: insets.top + spacing.lg, paddingBottom: spacing.xxl * 2 }}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={!ready}
          onRefresh={() => undefined}
          tintColor={palette.primary}
          title="Syncing today…"
        />
      }
    >
      <Text style={styles.greeting}>
        {greeting(hour)}
        {name ? `, ${name}` : ''}
      </Text>
      <Text style={styles.date}>{formatLongDate(today)}</Text>

      <View style={styles.hero}>
        <ProgressRing
          size={168}
          strokeWidth={15}
          progress={completion.ratio}
          color={palette.primary}
          centerLabel={`${Math.round(completion.ratio * 100)}%`}
          centerSub={`${completion.done} of ${completion.due} done`}
        />
        <View style={styles.heroCopy}>
          <Text style={styles.heroTitle}>
            {completion.due > 0 && completion.done === completion.due
              ? 'Perfect day 🔥'
              : completion.done === 0
                ? 'Let’s get one on the board'
                : 'Keep the momentum going'}
          </Text>
          <Text style={styles.heroBody}>
            {completion.due > 0 && completion.done === completion.due
              ? 'Every habit checked off. Enjoy it.'
              : `${completion.due - completion.done} habit${
                  completion.due - completion.done === 1 ? '' : 's'
                } left to close out today.`}
          </Text>
          <View style={styles.heroPills}>
            <Pill
              label={`7-day avg ${Math.round(weekAverage * 100)}%`}
              active
              onPress={() => undefined}
            />
          </View>
        </View>
      </View>

      <SectionTitle>Today’s habits</SectionTitle>

      {dueToday.map((habit) => (
        <HabitCard
          key={habit.id}
          habit={habit}
          logs={state.logs}
          dateKey={today}
          streak={currentStreak(habit, state.logs, today)}
          onPress={() => navigation.navigate('HabitDetail', { habitId: habit.id })}
          onCheck={() => checkIn(habit.id)}
          onStep={(delta) => bumpValue(habit.id, delta)}
        />
      ))}

      <View style={{ marginTop: spacing.md }}>
        <AppButton
          label="Add a habit"
          icon="＋"
          variant="secondary"
          onPress={() => navigation.navigate('AddEditHabit', {})}
        />
      </View>

      <SectionTitle>At a glance</SectionTitle>
      <View style={styles.statRow}>
        <StatTile label="Active habits" value={`${activeHabits.length}`} />
        <StatTile
          label="Perfect days"
          value={`${perfectDays}`}
          hint="last 30 days"
          accent={palette.success}
        />
        <StatTile
          label="Top day"
          value={
            bestWeekdayIndex >= 0 ? weekdayNames[bestWeekdayIndex].slice(0, 3) : '—'
          }
          hint="most consistent"
          accent={palette.warning}
        />
      </View>
    </ScrollView>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: palette.background, paddingHorizontal: spacing.lg },
    greeting: { color: palette.text, fontSize: 26, fontWeight: '800' },
    date: { color: palette.textMuted, fontSize: 14, marginTop: 2, marginBottom: spacing.lg },
    hero: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: spacing.lg,
      backgroundColor: palette.surface,
      borderRadius: radius.xl,
      borderWidth: 1,
      borderColor: palette.border,
      padding: spacing.lg,
    },
    heroCopy: { flex: 1 },
    heroTitle: { color: palette.text, fontSize: 16, fontWeight: '800' },
    heroBody: { color: palette.textMuted, fontSize: 13, marginTop: spacing.xs, lineHeight: 18 },
    heroPills: { flexDirection: 'row', marginTop: spacing.md },
    statRow: { flexDirection: 'row', gap: spacing.sm, flexWrap: 'wrap' },
  });
}
