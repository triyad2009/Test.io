import React, { useMemo, useState } from 'react';
import {
  Alert,
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { AppButton, Pill } from '../components/AppButton';
import { EmptyState } from '../components/EmptyState';
import { HabitCard } from '../components/HabitCard';
import { filterOptions, FilterOption } from '../constants';
import { useHabits } from '../hooks/useHabits';
import { RootStackParamList, filterHabits } from '../navigation/types';
import { Palette, radius, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';
import { todayKey } from '../utils/date';
import { currentStreak } from '../utils/streaks';

type Props = NativeStackScreenProps<RootStackParamList, 'Tabs'>;

export function HabitsScreen({ navigation }: { navigation: Props['navigation'] }) {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);
  const insets = useSafeAreaInsets();
  const { state, checkIn, bumpValue, setArchived, deleteHabit } = useHabits();
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<FilterOption>('All');
  const today = todayKey();

  const visible = useMemo(
    () => filterHabits(state.habits, filter, query),
    [state.habits, filter, query],
  );

  const counts = useMemo(
    () => ({
      all: state.habits.length,
      active: state.habits.filter((h) => !h.archived).length,
      archived: state.habits.filter((h) => h.archived).length,
    }),
    [state.habits],
  );

  const openMenu = (id: string) => {
    const habit = state.habits.find((h) => h.id === id);
    if (!habit) return;
    Alert.alert(habit.name, 'What would you like to do?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: habit.archived ? 'Unarchive' : 'Archive',
        onPress: () => setArchived(id, !habit.archived),
      },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () =>
          Alert.alert('Delete habit?', 'This removes the habit and all of its history.', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Delete', style: 'destructive', onPress: () => deleteHabit(id) },
          ]),
      },
    ]);
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top + spacing.lg }]}>
      <Text style={styles.heading}>Your habits</Text>
      <Text style={styles.subheading}>
        {counts.active} active · {counts.archived} archived
      </Text>

      <View style={styles.searchWrap}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Search habits"
          placeholderTextColor={palette.textFaint}
          style={styles.searchInput}
          autoCorrect={false}
          accessibilityLabel="Search habits"
          returnKeyType="search"
        />
        {query.length > 0 ? (
          <Pressable onPress={() => setQuery('')} hitSlop={10} accessibilityLabel="Clear search">
            <Text style={styles.clear}>✕</Text>
          </Pressable>
        ) : null}
      </View>

      <View style={styles.filters}>
        {filterOptions.map((option) => (
          <Pill
            key={option}
            label={option}
            active={filter === option}
            onPress={() => setFilter(option)}
          />
        ))}
      </View>

      <FlatList
        data={visible}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: spacing.xxl * 3 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View>
            <HabitCard
              habit={item}
              logs={state.logs}
              dateKey={today}
              streak={currentStreak(item, state.logs, today)}
              onPress={() => navigation.navigate('HabitDetail', { habitId: item.id })}
              onCheck={() => checkIn(item.id)}
              onStep={(delta) => bumpValue(item.id, delta)}
            />
            <Pressable
              onPress={() => openMenu(item.id)}
              style={styles.menuBtn}
              accessibilityRole="button"
              accessibilityLabel={`More options for ${item.name}`}
              hitSlop={8}
            >
              <Text style={styles.menuText}>⋯</Text>
            </Pressable>
          </View>
        )}
        ListEmptyComponent={
          <EmptyState
            emoji={query ? '🔍' : '📋'}
            title={query ? 'Nothing matched' : 'No habits in this view'}
            body={
              query
                ? `No habit matches “${query}”. Try a different word.`
                : 'Create a habit to see it listed here.'
            }
          />
        }
      />

      <View style={[styles.fab, { bottom: spacing.xl }]}>
        <AppButton
          label="New habit"
          icon="＋"
          fullWidth={false}
          onPress={() => navigation.navigate('AddEditHabit', {})}
        />
      </View>
    </View>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: palette.background, paddingHorizontal: spacing.lg },
    heading: { color: palette.text, fontSize: 26, fontWeight: '800' },
    subheading: { color: palette.textMuted, fontSize: 13, marginTop: 2, marginBottom: spacing.lg },
    searchWrap: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: spacing.sm,
      backgroundColor: palette.surface,
      borderRadius: radius.md,
      borderWidth: 1,
      borderColor: palette.border,
      paddingHorizontal: spacing.md,
      height: 46,
    },
    searchIcon: { fontSize: 14 },
    searchInput: { flex: 1, color: palette.text, fontSize: 15, paddingVertical: 0 },
    clear: { color: palette.textFaint, fontSize: 15 },
    filters: { flexDirection: 'row', gap: spacing.sm, marginVertical: spacing.lg },
    menuBtn: {
      position: 'absolute',
      right: spacing.md,
      top: spacing.md,
      width: 30,
      height: 30,
      borderRadius: 15,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: `${palette.surfaceAlt}`,
    },
    menuText: { color: palette.textMuted, fontSize: 18, fontWeight: '800', lineHeight: 20 },
    fab: { position: 'absolute', right: spacing.lg },
  });
}
