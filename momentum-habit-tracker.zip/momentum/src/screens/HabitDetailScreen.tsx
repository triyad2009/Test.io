import React, { useMemo } from 'react';
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { AppButton, SectionTitle } from '../components/AppButton';
import { Card, Divider } from '../components/EmptyState';
import { Heatmap } from '../components/Charts';
import { ProgressRing } from '../components/ProgressRing';
import { StatTile } from '../components/StatTile';
import { reminderPresets } from '../constants';
import { useHabits } from '../hooks/useHabits';
import { RootStackParamList } from '../navigation/types';
import { Palette, radius, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';
import { formatTime, lastNDays, todayKey } from '../utils/date';
import { isDoneOn, statsFor, valueFor } from '../utils/streaks';

type Props = NativeStackScreenProps<RootStackParamList, 'HabitDetail'>;

export function HabitDetailScreen({ route, navigation }: Props) {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);
  const insets = useSafeAreaInsets();
  const { state, setArchived, deleteHabit, clearDay, setReminder } = useHabits();
  const { habitId } = route.params;

  const habit = useMemo(() => state.habits.find((h) => h.id === habitId), [state.habits, habitId]);
  const today = todayKey();

  const stats = useMemo(
    () => (habit ? statsFor(habit, state.logs, today) : null),
    [habit, state.logs, today],
  );

  const recent = useMemo(() => {
    if (!habit) return [];
    return lastNDays(14, today)
      .slice()
      .reverse()
      .map((key) => ({
        key,
        value: valueFor(habit, state.logs, key),
        done: isDoneOn(habit, state.logs, key),
      }));
  }, [habit, state.logs, today]);

  if (!habit || !stats) {
    return (
      <View style={[styles.container, { paddingTop: insets.top + spacing.xl }]}>
        <Text style={styles.title}>Habit not found</Text>
        <Text style={styles.body}>It may have been deleted.</Text>
        <View style={{ marginTop: spacing.xl }}>
          <AppButton label="Go back" onPress={() => navigation.goBack()} />
        </View>
      </View>
    );
  }

  const onPickReminder = () => {
    Alert.alert(
      'Reminder',
      'Local daily reminder for this habit.',
      [
        ...reminderPresets.map((preset) => ({
          text: preset.label,
          onPress: async () => {
            const ok = await setReminder(habit.id, preset.value);
            if (preset.value && !ok) {
              Alert.alert(
                'Reminders unavailable',
                'Notification permission was denied or this build cannot schedule notifications. Enable notifications for Momentum in system settings and try again.',
              );
            }
          },
        })),
        { text: 'Cancel', style: 'cancel' as const },
      ],
    );
  };

  const onDelete = () => {
    Alert.alert('Delete habit?', 'This removes the habit and all of its history.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          await deleteHabit(habit.id);
          navigation.goBack();
        },
      },
    ]);
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingTop: spacing.xl, paddingBottom: spacing.xxl * 2 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <View style={[styles.bigEmoji, { backgroundColor: `${habit.color}22` }]}>
          <Text style={{ fontSize: 30 }}>{habit.emoji}</Text>
        </View>
        <Text style={styles.title}>{habit.name}</Text>
        <Text style={styles.body}>
          {habit.kind === 'count'
            ? `Goal: ${habit.goal}${habit.unit ? ` ${habit.unit}` : ''} per day`
            : 'Daily habit'}
          {habit.archived ? ' · Archived' : ''}
        </Text>
      </View>

      <View style={styles.ringWrap}>
        <ProgressRing
          size={160}
          strokeWidth={15}
          progress={stats.completionRate}
          color={habit.color}
          centerLabel={`${Math.round(stats.completionRate * 100)}%`}
          centerSub="last 30 days"
        />
      </View>

      <View style={styles.statRow}>
        <StatTile label="Current" value={`${stats.current}`} hint="day streak" accent={habit.color} />
        <StatTile label="Best" value={`${stats.best}`} hint="day streak" accent={palette.warning} />
        <StatTile label="Total" value={`${stats.total}`} hint="days done" accent={palette.success} />
      </View>

      <SectionTitle>Today</SectionTitle>
      <Card>
        <Text style={styles.todayTitle}>
          {stats.todayDone
            ? 'Completed ✓'
            : `${stats.todayValue} of ${habit.kind === 'check' ? 1 : habit.goal}`}
        </Text>
        <Text style={styles.body}>
          {stats.todayDone
            ? 'Nice — today is banked.'
            : 'Not yet logged. Tap the check on the list, or clear it below.'}
        </Text>
        <View style={{ marginTop: spacing.lg, gap: spacing.sm }}>
          <AppButton
            label="Clear today"
            variant="ghost"
            onPress={() => clearDay(habit.id)}
            disabled={stats.todayValue === 0}
          />
        </View>
      </Card>

      <SectionTitle>History</SectionTitle>
      <Card>
        <Heatmap habit={habit} logs={state.logs} weeks={16} />
      </Card>

      <SectionTitle>Last 14 days</SectionTitle>
      <Card>
        {recent.map((entry, index) => (
          <View key={entry.key}>
            <View style={styles.logRow}>
              <Text style={styles.logDate}>{entry.key}</Text>
              <Text style={[styles.logValue, entry.done && { color: habit.color }]}>
                {entry.value > 0 ? `${entry.value}${entry.done ? ' ✓' : ''}` : '—'}
              </Text>
            </View>
            {index < recent.length - 1 ? <Divider /> : null}
          </View>
        ))}
      </Card>

      <SectionTitle>Reminder</SectionTitle>
      <Card>
        <Text style={styles.todayTitle}>
          {habit.reminder ? formatTime(habit.reminder) : 'No reminder set'}
        </Text>
        <Text style={styles.body}>A daily local notification nudges you at this time.</Text>
        <View style={{ marginTop: spacing.lg }}>
          <AppButton label="Change reminder" variant="secondary" onPress={onPickReminder} />
        </View>
      </Card>

      <SectionTitle>Manage</SectionTitle>
      <View style={{ gap: spacing.sm }}>
        <AppButton
          label="Edit habit"
          variant="secondary"
          onPress={() => navigation.navigate('AddEditHabit', { habitId: habit.id })}
        />
        <AppButton
          label={habit.archived ? 'Unarchive' : 'Archive'}
          variant="ghost"
          onPress={() => setArchived(habit.id, !habit.archived)}
        />
        <AppButton label="Delete habit" variant="danger" onPress={onDelete} />
      </View>
    </ScrollView>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: palette.background, paddingHorizontal: spacing.lg },
    header: { alignItems: 'center' },
    bigEmoji: {
      width: 68,
      height: 68,
      borderRadius: radius.lg,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: spacing.md,
    },
    title: { color: palette.text, fontSize: 22, fontWeight: '800', textAlign: 'center' },
    body: { color: palette.textMuted, fontSize: 13, marginTop: spacing.xs, textAlign: 'center', lineHeight: 19 },
    ringWrap: { alignItems: 'center', marginTop: spacing.xl },
    statRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.xl, flexWrap: 'wrap' },
    todayTitle: { color: palette.text, fontSize: 16, fontWeight: '800', textAlign: 'center' },
    logRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: spacing.sm },
    logDate: { color: palette.textMuted, fontSize: 13 },
    logValue: { color: palette.text, fontSize: 13, fontWeight: '700' },
  });
}
