import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Pill, SectionTitle } from '../components/AppButton';
import { EmptyState } from '../components/EmptyState';
import { BarChart } from '../components/Charts';
import { ProgressRing } from '../components/ProgressRing';
import { StatTile } from '../components/StatTile';
import { useHabits } from '../hooks/useHabits';
import { Palette, radius, spacing } from '../theme/theme';
import { useAppTheme } from '../theme/useAppTheme';
import { formatMonthShort, lastNDays, todayKey } from '../utils/date';
import { completionSeries, currentStreak, statsFor, weekdayPattern } from '../utils/streaks';

const RANGES = [
  { label: '7 days', days: 7 },
  { label: '30 days', days: 30 },
  { label: '90 days', days: 90 },
];

export function StatsScreen() {
  const { palette } = useAppTheme();
  const styles = makeStyles(palette);
  const insets = useSafeAreaInsets();
  const { state } = useHabits();
  const [rangeIndex, setRangeIndex] = useState(1);
  const days = RANGES[rangeIndex].days;
  const today = todayKey();

  const activeHabits = useMemo(() => state.habits.filter((h) => !h.archived), [state.habits]);

  const series = useMemo(
    () => completionSeries(activeHabits, state.logs, lastNDays(days, today)),
    [activeHabits, state.logs, days, today],
  );

  const keys = useMemo(() => lastNDays(days, today), [days, today]);

  const average = useMemo(
    () => (series.length === 0 ? 0 : series.reduce((a, b) => a + b, 0) / series.length),
    [series],
  );

  const perHabit = useMemo(
    () =>
      activeHabits
        .map((habit) => ({ habit, stats: statsFor(habit, state.logs, today) }))
        .sort((a, b) => b.stats.completionRate - a.stats.completionRate),
    [activeHabits, state.logs, today],
  );

  const totalCheckIns = useMemo(
    () => perHabit.reduce((sum, item) => sum + item.stats.total, 0),
    [perHabit],
  );

  const longestStreak = useMemo(
    () => perHabit.reduce((max, item) => Math.max(max, item.stats.best), 0),
    [perHabit],
  );

  const pattern = useMemo(
    () => weekdayPattern(activeHabits, state.logs, 56, today),
    [activeHabits, state.logs, today],
  );

  const weekdayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  if (activeHabits.length === 0) {
    return (
      <View style={[styles.container, { paddingTop: insets.top + spacing.lg }]}>
        <EmptyState
          emoji="📊"
          title="No data to chart yet"
          body="Stats light up as soon as you have at least one habit logging days."
        />
      </View>
    );
  }

  // Keep the x-axis readable: label only every Nth day for wide ranges.
  const tickEvery = days <= 7 ? 1 : days <= 30 ? 3 : 13;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingTop: insets.top + spacing.lg, paddingBottom: spacing.xxl * 2 }}
      showsVerticalScrollIndicator={false}
    >
      <Text style={styles.heading}>Statistics</Text>
      <Text style={styles.subheading}>How consistent you’ve actually been</Text>

      <View style={styles.rangeRow}>
        {RANGES.map((range, index) => (
          <Pill
            key={range.label}
            label={range.label}
            active={index === rangeIndex}
            onPress={() => setRangeIndex(index)}
          />
        ))}
      </View>

      <View style={styles.summaryCard}>
        <ProgressRing
          size={132}
          strokeWidth={13}
          progress={average}
          color={palette.success}
          centerLabel={`${Math.round(average * 100)}%`}
          centerSub="average"
        />
        <View style={styles.summaryCopy}>
          <Text style={styles.summaryTitle}>Completion rate</Text>
          <Text style={styles.summaryBody}>
            Across {activeHabits.length} active habit{activeHabits.length === 1 ? '' : 's'} over the
            last {days} days.
          </Text>
          <Text style={styles.summaryBody}>
            {average >= 0.8
              ? 'Elite consistency. Genuinely.'
              : average >= 0.5
                ? 'Solid. Tighten one weak day and it climbs fast.'
                : 'Streaks start small — just close today.'}
          </Text>
        </View>
      </View>

      <SectionTitle>Daily completion</SectionTitle>
      <View style={styles.chartCard}>
        <BarChart
          values={series}
          labels={keys.map((key, index) =>
            index % tickEvery === 0 ? formatMonthShort(key) + ' ' + key.slice(8) : '',
          )}
          color={palette.primary}
          height={140}
        />
      </View>

      <SectionTitle>Totals</SectionTitle>
      <View style={styles.statRow}>
        <StatTile label="Check-ins" value={`${totalCheckIns}`} hint={`last ${days} days`} />
        <StatTile
          label="Best streak"
          value={`${longestStreak}`}
          hint="days in a row"
          accent={palette.warning}
        />
        <StatTile
          label="Habits tracked"
          value={`${activeHabits.length}`}
          accent={palette.success}
        />
      </View>

      <SectionTitle>By habit</SectionTitle>
      {perHabit.map(({ habit, stats }) => (
        <View key={habit.id} style={styles.habitRow}>
          <View style={[styles.habitDot, { backgroundColor: `${habit.color}22` }]}>
            <Text style={{ fontSize: 18 }}>{habit.emoji}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.habitName} numberOfLines={1}>
              {habit.name}
            </Text>
            <Text style={styles.habitMeta}>
              🔥 {currentStreak(habit, state.logs, today)} current · best {stats.best} ·{' '}
              {stats.total} total
            </Text>
          </View>
          <Text style={[styles.habitRate, { color: habit.color }]}>
            {Math.round(stats.completionRate * 100)}%
          </Text>
        </View>
      ))}

      <SectionTitle>Best weekdays</SectionTitle>
      <View style={styles.chartCard}>
        <BarChart
          values={pattern}
          labels={weekdayLabels.map((w) => w.slice(0, 1))}
          color={palette.warning}
          height={110}
        />
        <Text style={styles.footnote}>Completion rate by day of week, last 8 weeks.</Text>
      </View>
    </ScrollView>
  );
}

function makeStyles(palette: Palette) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: palette.background, paddingHorizontal: spacing.lg },
    heading: { color: palette.text, fontSize: 26, fontWeight: '800' },
    subheading: { color: palette.textMuted, fontSize: 13, marginTop: 2 },
    rangeRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.lg },
    summaryCard: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: spacing.lg,
      backgroundColor: palette.surface,
      borderRadius: radius.xl,
      borderWidth: 1,
      borderColor: palette.border,
      padding: spacing.lg,
      marginTop: spacing.lg,
    },
    summaryCopy: { flex: 1 },
    summaryTitle: { color: palette.text, fontSize: 16, fontWeight: '800' },
    summaryBody: { color: palette.textMuted, fontSize: 12.5, marginTop: spacing.xs, lineHeight: 18 },
    chartCard: {
      backgroundColor: palette.surface,
      borderRadius: radius.lg,
      borderWidth: 1,
      borderColor: palette.border,
      padding: spacing.lg,
    },
    statRow: { flexDirection: 'row', gap: spacing.sm, flexWrap: 'wrap' },
    habitRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: spacing.md,
      backgroundColor: palette.surface,
      borderRadius: radius.lg,
      borderWidth: 1,
      borderColor: palette.border,
      padding: spacing.md,
      marginBottom: spacing.sm,
    },
    habitDot: { width: 40, height: 40, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
    habitName: { color: palette.text, fontSize: 15, fontWeight: '700' },
    habitMeta: { color: palette.textMuted, fontSize: 12, marginTop: 2 },
    habitRate: { fontSize: 15, fontWeight: '800' },
    footnote: { color: palette.textFaint, fontSize: 11, marginTop: spacing.md, textAlign: 'center' },
  });
}
