import 'react-native-gesture-handler';
import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { RootNavigator } from './src/navigation/RootNavigator';
import { HabitProvider } from './src/store/HabitContext';
import { useAppTheme } from './src/theme/useAppTheme';

/**
 * Navigation theme is derived from the same palette the screens use, so the
 * stack header, tab bar and screen backgrounds always agree — including when
 * the user overrides the system theme.
 */
function ThemedApp() {
  const { palette, isDark } = useAppTheme();

  const navTheme = {
    ...(isDark ? DarkTheme : DefaultTheme),
    colors: {
      ...(isDark ? DarkTheme : DefaultTheme).colors,
      primary: palette.primary,
      background: palette.background,
      card: palette.surface,
      text: palette.text,
      border: palette.border,
      notification: palette.danger,
    },
  };

  return (
    <NavigationContainer theme={navTheme}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <RootNavigator />
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <HabitProvider>
        <ThemedApp />
      </HabitProvider>
    </SafeAreaProvider>
  );
}
