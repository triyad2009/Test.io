/**
 * Dependency-free verification of the pure logic that everything else depends on.
 * Run with: npm run test
 *
 * It compiles src/utils/*.ts with tsc and executes the assertions in plain Node,
 * so date maths and streak maths can be checked without a device or emulator.
 */
import {
  addDays,
  diffDays,
  formatTime,
  fromKey,
  lastNDays,
  toKey,
  todayKey,
} from '../src/utils/date';
import {
  bestStreak,
  completionRate,
  currentStreak,
  dayCompletion,
  dayProgress,
  isComplete,
  isDoneOn,
  statsFor,
  totalCompletions,
  valueFor,
  weekdayPattern,
} from '../src/utils/streaks';
import { createId } from '../src/utils/id';
import { Habit, Logs } from '../src/types';

let passed = 0;
const failures: string[] = [];

function check(name: string, condition: boolean, detail = ''): void {
  if (condition) {
    passed += 1;
    console.log(`  ok   ${name}`);
  } else {
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
    console.log(`  FAIL ${name}${detail ? ` — ${detail}` : ''}`);
  }
}

function eq(name: string, actual: unknown, expected: unknown): void {
  check(name, actual === expected, `expected ${String(expected)}, got ${String(actual)}`);
}

console.log('\ndate utils');
eq('toKey pads month and day', toKey(new Date(2026, 0, 5)), '2026-01-05');
eq('toKey round trip via fromKey', toKey(fromKey('2026-09-21')), '2026-09-21');
eq('addDays crosses month boundary', addDays('2026-08-31', 1), '2026-09-01');
eq('addDays goes backwards across year', addDays('2026-01-01', -1), '2025-12-31');
eq('diffDays forward', diffDays('2026-09-01', '2026-09-21'), 20);
eq('diffDays backward', diffDays('2026-09-21', '2026-09-01'), -20);
eq('diffDays same day', diffDays('2026-09-21', '2026-09-21'), 0);

const thirty = lastNDays(30, '2026-09-21');
eq('lastNDays returns the requested count', thirty.length, 30);
eq('lastNDays ends on the end key', thirty[29], '2026-09-21');
eq('lastNDays starts 29 days earlier', thirty[0], '2026-08-23');
check('lastNDays is strictly increasing', thirty.every((key, i) => i === 0 || diffDays(thirty[i - 1], key) === 1));

// Leap year + DST-safe arithmetic (noon anchor avoids off-by-one days).
eq('leap day exists in 2028', addDays('2028-02-28', 1), '2028-02-29');
eq('DST spring-forward stays on calendar', addDays('2026-03-28', 1), '2026-03-29');
eq('DST fall-back stays on calendar', addDays('2026-10-24', 1), '2026-10-25');

eq('formatTime morning', formatTime('07:00'), '7:00 AM');
eq('formatTime noon', formatTime('12:00'), '12:00 PM');
eq('formatTime evening', formatTime('21:30'), '9:30 PM');
eq('formatTime midnight', formatTime('00:15'), '12:15 AM');

console.log('\nstreak utils');

function makeHabit(overrides: Partial<Habit> = {}): Habit {
  return {
    id: 'h_test',
    name: 'Test',
    emoji: '🎯',
    color: '#4F46E5',
    kind: 'check',
    goal: 1,
    unit: '',
    createdAt: '2026-09-01',
    reminder: null,
    reminderId: null,
    archived: false,
    ...overrides,
  };
}

const today = '2026-09-21';

// A clean 5-day run finishing today.
const runHabit = makeHabit();
const runLogs: Logs = {
  h_test: {
    '2026-09-17': 1,
    '2026-09-18': 1,
    '2026-09-19': 1,
    '2026-09-20': 1,
    '2026-09-21': 1,
  },
};
eq('currentStreak counts the run ending today', currentStreak(runHabit, runLogs, today), 5);
eq('bestStreak for a single run', bestStreak(runHabit, runLogs, today), 5);
eq(
  'bestStreak equals current for an unbroken run',
  bestStreak(runHabit, runLogs, today),
  currentStreak(runHabit, runLogs, today),
);
eq('totalCompletions', totalCompletions(runHabit, runLogs), 5);

// Streak must survive an untouched today, but break when yesterday is missing.
const yesterdayOnly: Logs = {
  h_test: { '2026-09-18': 1, '2026-09-19': 1, '2026-09-20': 1 },
};
eq('untouched today keeps the streak visible', currentStreak(runHabit, yesterdayOnly, today), 3);

// Yesterday missing entirely -> the live streak is genuinely broken.
const noYesterday: Logs = {
  h_test: { '2026-09-16': 1, '2026-09-17': 1 },
};
eq('missing yesterday breaks the streak to zero', currentStreak(runHabit, noYesterday, today), 0);

// An older gap must not erase a run that is still live (19-20 are consecutive).
const olderGap: Logs = {
  h_test: { '2026-09-16': 1, '2026-09-17': 1, '2026-09-19': 1, '2026-09-20': 1 },
};
eq('older gap keeps the live run of 2', currentStreak(runHabit, olderGap, today), 2);
eq(
  'bestStreak picks the longer of two runs',
  bestStreak(runHabit, olderGap, today),
  2,
);

// Best streak must still be found for a long broken history.
const longHistory: Logs = {
  h_test: {
    '2026-09-05': 1,
    '2026-09-06': 1,
    '2026-09-07': 1,
    '2026-09-08': 1,
    '2026-09-20': 1,
    '2026-09-21': 1,
  },
};
eq('bestStreak finds a 4-day run in the past', bestStreak(runHabit, longHistory, today), 4);
eq('currentStreak reflects only the live run', currentStreak(runHabit, longHistory, today), 2);

const emptyLogs: Logs = {};
eq('no logs means no streak', currentStreak(runHabit, emptyLogs, today), 0);
eq('no logs means no best', bestStreak(runHabit, emptyLogs, today), 0);

// A habit created in the future must not produce a negative or infinite streak.
const futureHabit = makeHabit({ createdAt: '2026-10-01' });
eq('future habit has zero streak', currentStreak(futureHabit, emptyLogs, today), 0);
eq('future habit has zero best', bestStreak(futureHabit, emptyLogs, today), 0);

// A very old habit must not hang the backwards scan (guard cap).
const ancientHabit = makeHabit({ createdAt: '1990-01-01' });
const ancientLogs: Logs = { h_test: { '2026-09-21': 1 } };
eq('ancient habit: single-day streak', currentStreak(ancientHabit, ancientLogs, today), 1);
eq(
  'ancient habit: best streak still sees recent days',
  bestStreak(ancientHabit, ancientLogs, today),
  1,
);
// The old forward-walk bug reported 0 here; the backwards walk fixes it.
check(
  'ancient habit best streak is never wrongly zero when today is logged',
  bestStreak(ancientHabit, ancientLogs, today) > 0,
);
const ancientNoLogs = bestStreak(ancientHabit, emptyLogs, today);
eq('ancient habit with no logs gives best 0 (and terminates)', ancientNoLogs, 0);

// Count habits: partial progress is not a completed day.
const countHabit = makeHabit({ kind: 'count', goal: 8, unit: 'glasses' });
const countLogs: Logs = {
  h_test: {
    '2026-09-19': 3,
    '2026-09-20': 8,
    '2026-09-21': 10,
  },
};
eq('goal hit counts as complete', isDoneOn(countHabit, countLogs, '2026-09-20'), true);
eq('over-achieving still counts as complete', isDoneOn(countHabit, countLogs, '2026-09-21'), true);
eq('partial progress is not complete', isDoneOn(countHabit, countLogs, '2026-09-19'), false);
eq('count streak skips the partial day', currentStreak(countHabit, countLogs, today), 2);
check('dayProgress is clamped to 1', dayProgress(countHabit, countLogs, '2026-09-21') === 1);
check('dayProgress handles partial days', dayProgress(countHabit, countLogs, '2026-09-19') === 3 / 8);
check('dayProgress is 0 with no data', dayProgress(countHabit, emptyLogs, today) === 0);

eq('valueFor returns the stored count', valueFor(countHabit, countLogs, '2026-09-19'), 3);
eq('valueFor returns 0 for empty days', valueFor(countHabit, countLogs, '2026-09-18'), 0);

// completionRate over an explicit window.
const rateHabit = makeHabit({ createdAt: '2026-09-01' });
const rateLogs: Logs = {
  h_test: {
    '2026-09-17': 1,
    '2026-09-18': 1,
    '2026-09-19': 1,
    '2026-09-20': 1,
    '2026-09-21': 1,
  },
};
check(
  'completionRate over 10 days is 5/10',
  Math.abs(completionRate(rateHabit, rateLogs, 10, today) - 0.5) < 1e-9,
);
check(
  'completionRate over 5 days is 1.0',
  Math.abs(completionRate(rateHabit, rateLogs, 5, today) - 1) < 1e-9,
);
check(
  'completionRate over 2 days is 1.0',
  Math.abs(completionRate(rateHabit, rateLogs, 2, today) - 1) < 1e-9,
);

// completionRate must not count days before the habit existed.
const newborn = makeHabit({ createdAt: today });
check(
  'new habit completionRate does not penalise pre-creation days',
  Math.abs(completionRate(newborn, { h_test: { [today]: 1 } }, 30, today) - 1) < 1e-9,
);

// Archived habits are never "due".
const archived = makeHabit({ archived: true });
const due = dayCompletion([runHabit, archived], runLogs, today);
eq('archived habits excluded from day completion (done)', due.done, 1);
eq('archived habits excluded from day completion (due)', due.due, 1);
check('day completion ratio is 1', Math.abs(due.ratio - 1) < 1e-9);

const noDue = dayCompletion([archived], runLogs, today);
eq('no due habits gives zero ratio (no divide by zero)', noDue.ratio, 0);

// Stats bundle agrees with its parts.
const bundle = statsFor(countHabit, countLogs, today);
eq('statsFor.current', bundle.current, 2);
eq('statsFor.best', bundle.best, 2);
eq('statsFor.total', bundle.total, 2);
eq('statsFor.todayValue', bundle.todayValue, 10);
eq('statsFor.todayDone', bundle.todayDone, true);
check('statsFor.trackedDays is positive', bundle.trackedDays > 0);

// weekdayPattern length and bounds.
const pattern = weekdayPattern([runHabit], runLogs, 14, today);
eq('weekdayPattern has 7 buckets', pattern.length, 7);
check('weekdayPattern values stay within 0..1', pattern.every((v) => v >= 0 && v <= 1));
check('weekdayPattern index 0 is Sunday', fromKey('2026-09-20').getDay() === 0);
check(
  'weekdayPattern marks the logged Sunday',
  pattern[0] > 0,
  `sunday bucket was ${pattern[0]}`,
);

console.log('\nid utils');
const idA = createId('habit');
const idB = createId('habit');
check('createId is prefixed', idA.startsWith('habit_'));
check('createId produces unique values', idA !== idB);
check('createId is reasonably long', idA.length > 15);

// Same-day duplicate ids must never collide inside one batch.
const batch = new Set(Array.from({ length: 500 }, () => createId('h')));
eq('500 ids in one tick are unique', batch.size, 500);

console.log('\nsanity');
eq('a fresh habit with no logs is not complete', isComplete(valueFor(newborn, emptyLogs, today), newborn), false);
eq('todayKey matches a manual Date build', todayKey(), toKey(new Date()));

console.log(`\n${passed} passed, ${failures.length} failed`);
if (failures.length > 0) {
  console.log('\nFailures:');
  failures.forEach((f) => console.log(`  - ${f}`));
  process.exit(1);
}
console.log('All logic checks passed.\n');
