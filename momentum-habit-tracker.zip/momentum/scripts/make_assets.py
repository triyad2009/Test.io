"""Generates the Expo app icon set so `expo start` / EAS builds find real assets."""
from PIL import Image, ImageDraw
import os

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
os.makedirs(OUT, exist_ok=True)

INDIGO = (79, 70, 229, 255)
WHITE = (255, 255, 255, 255)


def rounded(size, radius, bg):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=bg)
    return img


def ring(img, size, cx, cy, r, width, color):
    d = ImageDraw.Draw(img)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=width)


def draw_mark(size, bg=None, ring_color=WHITE, pad_scale=1.0):
    """A rising momentum arc — two nested rings with a gap, resembling a streak."""
    if bg is None:
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    else:
        img = Image.new("RGBA", (size, size), bg)
    s = size * pad_scale
    off = (size - s) / 2
    cx = cy = size / 2
    ring(img, size, cx, cy, s * 0.30, max(2, int(size * 0.075)), ring_color)
    ring(img, size, cx, cy, s * 0.17, max(2, int(size * 0.075)), ring_color)
    d = ImageDraw.Draw(img)
    # Check tick through the middle, drawn as a thick polyline.
    w = max(2, int(size * 0.085))
    pts = [
        (cx - s * 0.10, cy + s * 0.01),
        (cx - s * 0.02, cy + s * 0.10),
        (cx + s * 0.13, cy - s * 0.12),
    ]
    d.line(pts, fill=ring_color, width=w, joint="curve")
    for p in pts:
        d.ellipse([p[0] - w / 2, p[1] - w / 2, p[0] + w / 2, p[1] + w / 2], fill=ring_color)
    return img


# 1. Main icon (1024) — rounded square, indigo background, white mark.
icon = rounded(1024, 224, INDIGO)
icon.alpha_composite(draw_mark(1024))
icon.save(os.path.join(OUT, "icon.png"))

# 2. Adaptive icon foreground (1024, transparent, mark kept inside the safe zone).
draw_mark(1024, pad_scale=0.66).save(os.path.join(OUT, "adaptive-icon.png"))

# 3. Splash (1284x2778 canvas, transparent mark centred) — Expo scales it.
splash = Image.new("RGBA", (1284, 2778), (0, 0, 0, 0))
mark = draw_mark(600)
splash.alpha_composite(mark, dest=(int((1284 - 600) / 2), int((2778 - 600) / 2)))
splash.save(os.path.join(OUT, "splash.png"))

# 4. Favicon for the web target (48).
fav = Image.new("RGBA", (48, 48), INDIGO)
fav.alpha_composite(draw_mark(48))
fav.save(os.path.join(OUT, "favicon.png"))

for name in ["icon.png", "adaptive-icon.png", "splash.png", "favicon.png"]:
    p = os.path.join(OUT, name)
    with Image.open(p) as im:
        print(f"{name:20s} {im.size[0]}x{im.size[1]} {im.mode} {os.path.getsize(p)} bytes")
print("assets written to", OUT)
