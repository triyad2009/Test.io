import { registerRootComponent } from 'expo';

import App from './App';

// registerRootComponent calls AppRegistry.registerComponent('main', () => App)
// and makes sure the environment is set up appropriately for Expo Go as well as
// for native debug/production builds.
registerRootComponent(App);
