# Momentum — Habit Tracker

A complete, offline-first habit tracker built with **Expo + React Native + TypeScript**.
One codebase, real native builds for **iOS and Android**. No backend, no account, no network calls —
every habit and log lives on the device in AsyncStorage.

---

## What's in it

| Area | Detail |
| --- | --- |
| **Today** | Greeting, completion ring, today's habit list, 7-day average, perfect-day count, strongest weekday |
| **Habits** | Full list, live text search, All / Active / Archived filters, per-row check + counter steppers, long-press menu to archive or delete |
| **Stats** | 7 / 30 / 90-day ranges, completion-rate ring, dependency-free bar chart, totals, per-habit breakdown, best-weekday chart |
| **Habit detail** | 30-day rate ring, current/best/total streaks, 16-week heatmap, last-14-days log, reminder picker, archive/delete |
| **Add / edit** | Live preview, 24 emoji icons, 10 colours, simple-check vs count-goal types, goal stepper, unit label, reminder presets |
| **Settings** | Display name, theme (System / Light / Dark), notification permission state, data summary, reload sample data, erase all |
| **Reminders** | Per-habit daily local notifications via `expo-notifications`, re-armed automatically when the time changes |
| **Extras** | Dark mode, accessibility labels/roles on every control, safe-area handling, formatters that never crash on bad storage data |

---

## Quick start

```bash
npm install

npm start          # Expo dev server — scan the QR with Expo Go
npm run ios        # iOS simulator (macOS + Xcode)
npm run android    # Android emulator
npm run typecheck  # tsc --noEmit across the whole project
npm test           # runs the pure-logic verification suite
```

`npm test` compiles `src/utils/*.ts` with `tsc` and executes the assertions in Node — no emulator
needed. It covers date keys across month/year/leap/DST boundaries, streak counting, partial
progress on count habits, completion-rate windows, archived-habit exclusion, divide-by-zero guards,
and id uniqueness.

---

## Project layout

```
momentum/
├── App.tsx                      # Providers + navigation theme wiring
├── index.ts                     # registerRootComponent
├── app.json                     # Expo config (icon, splash, bundle ids)
├── package.json / tsconfig.json / babel.config.js
├── assets/                      # Generated icon, adaptive icon, splash, favicon
├── scripts/
│   ├── verify.ts                # Pure-logic test suite (npm test)
│   └── make_assets.py           # Regenerates the PNG assets
└── src/
    ├── types.ts                 # Habit, Logs, Settings, HabitStats, PersistedState
    ├── constants.ts             # Emoji, colours, reminder presets, filters
    ├── components/
    │   ├── AppButton.tsx        # AppButton, Pill, SectionTitle
    │   ├── HabitCard.tsx        # List row with check/stepper + streak chip
    │   ├── ProgressRing.tsx     # SVG ring + ProgressBar
    │   ├── Charts.tsx           # Heatmap + dependency-free BarChart
    │   ├── StatTile.tsx         # Metric tile
    │   ├── Swatch.tsx           # Emoji/colour swatches, Stepper
    │   └── EmptyState.tsx       # EmptyState, Card, Divider
    ├── hooks/useHabits.ts       # Typed context accessor
    ├── navigation/
    │   ├── types.ts             # Param lists + list filter helpers
    │   ├── RootNavigator.tsx    # Native stack: Tabs → Detail → Add/Edit
    │   └── TabNavigator.tsx     # Bottom tabs with Ionicons
    ├── notifications/reminders.ts  # Lazy, guarded expo-notifications wrapper
    ├── screens/
    │   ├── TodayScreen.tsx
    │   ├── HabitsScreen.tsx
    │   ├── StatsScreen.tsx
    │   ├── HabitDetailScreen.tsx
    │   ├── AddEditHabitScreen.tsx
    │   └── SettingsScreen.tsx
    ├── storage/
    │   ├── persistence.ts       # AsyncStorage load/save + full state sanitisation
    │   └── seed.ts              # First-run sample habits with organic history
    ├── store/HabitContext.tsx   # Reducer, persistence, CRUD, reminder side effects
    ├── theme/
    │   ├── theme.ts             # Light/dark palettes, radius, spacing
    │   └── useAppTheme.ts       # Resolves palette from setting + OS appearance
    └── utils/
        ├── date.ts              # Local date keys, safe arithmetic, formatters
        ├── streaks.ts           # Streak / rate / completion maths
        └── id.ts                # Collision-resistant local ids
```

---

## Data model

```ts
Habit  { id, name, emoji, color, kind: 'check'|'count', goal, unit,
         createdAt, reminder, reminderId, archived }
Logs   { [habitId]: { [YYYY-MM-DD]: number } }
Settings { themeMode: 'system'|'light'|'dark', notificationsEnabled, displayName }
```

`kind: 'check'` is a boolean day (`goal` pinned to 1). `kind: 'count'` tracks a number against a
goal — a day only counts as complete once it reaches the target.

## Design notes

- **Storage is defensive.** `sanitizeState()` repairs or rejects malformed persisted JSON, so a bad
  write can never white-screen a screen. Habit ids absent from `logs` are pruned both ways.
- **Date maths is DST-safe.** Keys are built from the local calendar and parsed at noon, so a
  timezone shift never silently drops or duplicates a day.
- **Streak scans are bounded** by a 3650-day guard, so a corrupt `createdAt` can't freeze the UI.
- **Notifications degrade gracefully.** `expo-notifications` is required lazily and feature-detected;
  on web previews or builds without the module, the app runs normally with notifications off.
- **Navigation theme is derived from the same palette** the screens use, so headers, tabs and
  backgrounds can never fall out of sync — including when the user overrides the OS theme.

## Building for stores

```bash
npx eas build --platform ios
npx eas build --platform android
```

`app.json` ships bundle id `com.momentum.habittracker` and a placeholder `eas.projectId` — swap that
for your own EAS project id (`eas init`) before your first cloud build.
